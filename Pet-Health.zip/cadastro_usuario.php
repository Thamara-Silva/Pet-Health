<?php

require 'conexao.php';

$mensagem = '';
$tipoMensagem = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // 1. Coleta os dados do usuário.
    $nome_usuario = trim($_POST['nome_usuario'] ?? '');
    $email_usuario = trim($_POST['email_usuario'] ?? '');
    $telefone_usuario = trim($_POST['telefone_usuario'] ?? '');
    $senha_usuario = $_POST['senha_usuario'] ?? '';
    $confSenha = $_POST['confSenha'] ?? '';

    // 2. Coleta os dados do endereço.
    $logradouro = trim($_POST['logradouro'] ?? '');
    $numero = trim($_POST['numero'] ?? '');
    $complemento = trim($_POST['complemento'] ?? '');
    $bairro = trim($_POST['bairro'] ?? '');
    $cidade = trim($_POST['cidade'] ?? '');
    $uf = strtoupper(trim($_POST['uf'] ?? ''));
    $cep = trim($_POST['cep'] ?? '');

    // 3. Valida os dados.

    if (strlen($senha_usuario) < 8) {

        $mensagem = 'A senha deve ter pelo menos 8 caracteres!';
        $tipoMensagem = 'erro';

    } elseif ($senha_usuario !== $confSenha) {

        $mensagem = 'As senhas não coincidem!';
        $tipoMensagem = 'erro';

    } elseif (!filter_var($email_usuario, FILTER_VALIDATE_EMAIL)) {

        $mensagem = 'Informe um endereço de e-mail válido!';
        $tipoMensagem = 'erro';

    } else {

        try {

            // 4. Verifica se o usuário já existe.
            $stmt = $pdo->prepare("
                SELECT id_usuario
                FROM USUARIOS
                WHERE email_usuario = ? OR nome_usuario = ?
                LIMIT 1
            ");

            $stmt->execute([$email_usuario, $nome_usuario]);

            if ($stmt->fetch()) {

                $mensagem = 'Esse usuário já existe. Tente outro!';
                $tipoMensagem = 'erro';

            } else {

                // 5. Inicia a transação.
                $pdo->beginTransaction();

                // 6. Insere o endereço.
                $stmtEnd = $pdo->prepare("
                    INSERT INTO ENDERECOS
                        (logradouro, numero, complemento, bairro, cidade, uf, cep)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ");

                $stmtEnd->execute([
                    $logradouro,
                    $numero,
                    $complemento !== '' ? $complemento : null,
                    $bairro,
                    $cidade,
                    $uf,
                    $cep
                ]);

                $id_endereco_fk = $pdo->lastInsertId();

                // 7. Protege a senha.
                $hashsenha = password_hash(
                    $senha_usuario,
                    PASSWORD_DEFAULT
                );

                // 8. Insere o usuário.
                $stmtUser = $pdo->prepare("
                    INSERT INTO USUARIOS
                        (nome_usuario, email_usuario, senha_usuario, STATUS, telefone_usuario, id_endereco_fk)
                    VALUES (?, ?, ?, ?, ?, ?)
                ");

                $stmtUser->execute([
                    $nome_usuario,
                    $email_usuario,
                    $hashsenha,
                    'CLIENTE',
                    $telefone_usuario,
                    $id_endereco_fk
                ]);

                // 9. Confirma as duas inserções.
                $pdo->commit();

                $mensagem = 'Cadastro realizado com sucesso!';
                $tipoMensagem = 'sucesso';
            }

        } catch (PDOException $e) {

            // Desfaz as alterações se alguma etapa falhar.
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            error_log($e->getMessage());

            $mensagem = 'Não foi possível realizar o cadastro. Tente novamente.';
            $tipoMensagem = 'erro';
        }
    }
}

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Cadastro | Pet Health</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Coiny&family=Nunito:wght@400;500;600;700;800&display=swap"
        rel="stylesheet">

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Nunito', sans-serif;
        }

        body {
            min-height: 100vh;
            padding: 35px 15px;
            display: flex;
            justify-content: center;
            align-items: center;

            background:
                linear-gradient(rgba(118, 85, 163, 0.76),
                    rgba(185, 154, 222, 0.78)),
                url('./imgs/fundo.png');

            background-size: cover;
            background-position: center;
            background-attachment: fixed;
        }

        .container-cadastro {
            width: 100%;
            max-width: 620px;
            background: rgba(255, 255, 255, 0.97);
            padding: 38px 42px;
            border-radius: 25px;
            box-shadow: 0 15px 45px rgba(65, 40, 85, 0.23);
        }

        /* Identidade da marca */

        .logo {
            text-align: center;
            font-family: 'Coiny', cursive;
            font-size: 34px;
            color: #7655a3;
            margin-bottom: 5px;
        }

        .logo span {
            font-family: 'Coiny', cursive;
            color: #ef713f;
        }

        .subtitulo {
            text-align: center;
            color: #91859d;
            font-size: 14px;
            margin-bottom: 25px;
        }

        /* Mensagens */

        .mensagem {
            text-align: center;
            font-size: 14px;
            font-weight: 800;
            padding: 13px;
            border-radius: 12px;
            margin-bottom: 20px;
        }

        .mensagem.erro {
            color: #a03535;
            background: #fde8e8;
            border: 1px solid #f5b5b5;
        }

        .mensagem.sucesso {
            color: #2c6e3a;
            background: #e6f7eb;
            border: 1px solid #b7e3c2;
        }

        /* Formulário */

        .secao-titulo {
            color: #7655a3;
            font-size: 16px;
            font-weight: 800;
            margin: 25px 0 16px;
            padding-bottom: 9px;
            border-bottom: 2px solid #eee6f5;
        }

        .campo {
            width: 100%;
            margin-bottom: 17px;
        }

        .linha-dupla {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }

        label {
            display: block;
            color: #594176;
            font-size: 14px;
            font-weight: 800;
            margin-bottom: 7px;
        }

        input[type="text"],
        input[type="email"],
        input[type="tel"],
        input[type="password"] {
            width: 100%;
            height: 48px;
            padding: 0 14px;
            border: 2px solid #e6dcef;
            border-radius: 11px;
            outline: none;
            background: #fcfaff;
            color: #493d52;
            font-size: 14px;
            transition: 0.2s;
        }

        input:focus {
            border-color: #8e6bbe;
            background: white;
            box-shadow: 0 0 0 3px rgba(142, 107, 190, 0.12);
        }

        input::placeholder {
            color: #aa9bb3;
        }

        .uf {
            text-transform: uppercase;
        }

        /* Botões */

        .botao-cadastrar {
            width: 100%;
            height: 51px;
            border: none;
            border-radius: 12px;
            background: linear-gradient(90deg, #ef713f, #f28b62);
            color: white;
            font-size: 16px;
            font-weight: 800;
            cursor: pointer;
            margin-top: 8px;
            box-shadow: 0 5px 12px rgba(239, 113, 63, 0.2);
            transition: 0.2s;
        }

        .botao-cadastrar:hover {
            background: linear-gradient(90deg, #dc5f2f, #e97950);
            transform: translateY(-2px);
        }

        .botao-limpar {
            width: 100%;
            height: 46px;
            border: none;
            border-radius: 12px;
            background: #eee6f5;
            color: #7655a3;
            font-size: 15px;
            font-weight: 800;
            cursor: pointer;
            margin-top: 12px;
            transition: 0.2s;
        }

        .botao-limpar:hover {
            background: #dfd2eb;
        }

        .link-login {
            display: block;
            text-align: center;
            margin-top: 17px;
            padding: 12px;
            border-radius: 11px;
            text-decoration: none;
            color: #7655a3;
            background: #f3edfa;
            font-size: 14px;
            font-weight: 800;
            transition: 0.2s;
        }

        .link-login:hover {
            background: #e6d9f3;
        }

        /* Responsividade */

        @media (max-width: 550px) {
            .container-cadastro {
                padding: 28px 22px;
                border-radius: 20px;
            }

            .logo {
                font-size: 29px;
            }

            .linha-dupla {
                grid-template-columns: 1fr;
                gap: 0;
            }
        }
    </style>
</head>

<body>

    <main class="container-cadastro">

        <h1 class="logo">Pet <span>Health</span></h1>

        <p class="subtitulo">
            Crie sua conta e faça parte da nossa família!
        </p>

        <?php if (!empty($mensagem)): ?>

            <div class="mensagem <?= $tipoMensagem ?>">
                <?= htmlspecialchars($mensagem, ENT_QUOTES, 'UTF-8') ?>
            </div>

        <?php endif; ?>

        <form action="<?= htmlspecialchars($_SERVER['PHP_SELF'], ENT_QUOTES, 'UTF-8') ?>" method="POST">

            <h2 class="secao-titulo">Seus dados</h2>

            <div class="campo">
                <label for="nome_usuario">Nome completo:</label>
                <input type="text" id="nome_usuario" name="nome_usuario" maxlength="100" required>
            </div>

            <div class="campo">
                <label for="email_usuario">E-mail:</label>
                <input type="email" id="email_usuario" name="email_usuario" maxlength="100" required>
            </div>

            <div class="campo">
                <label for="telefone_usuario">Telefone:</label>
                <input type="tel" id="telefone_usuario" name="telefone_usuario" maxlength="20"
                    placeholder="(00) 00000-0000" required>
            </div>

            <div class="linha-dupla">

                <div class="campo">
                    <label for="senha_usuario">Senha:</label>
                    <input type="password" id="senha_usuario" name="senha_usuario" minlength="8" maxlength="60"
                        autocomplete="new-password" required>
                </div>

                <div class="campo">
                    <label for="confSenha">Confirmar senha:</label>
                    <input type="password" id="confSenha" name="confSenha" minlength="8" maxlength="60"
                        autocomplete="new-password" required>
                </div>

            </div>

            <h2 class="secao-titulo">📍 Endereço</h2>

            <div class="campo">
                <label for="logradouro">Logradouro:</label>
                <input type="text" id="logradouro" name="logradouro" maxlength="100" placeholder="Rua, Avenida, etc."
                    required>
            </div>

            <div class="linha-dupla">

                <div class="campo">
                    <label for="numero">Número:</label>
                    <input type="text" id="numero" name="numero" maxlength="10" placeholder="Ex.: 123" required>
                </div>

                <div class="campo">
                    <label for="complemento">Complemento:</label>
                    <input type="text" id="complemento" name="complemento" maxlength="50" placeholder="Apto, Bloco...">
                </div>

            </div>

            <div class="campo">
                <label for="bairro">Bairro:</label>
                <input type="text" id="bairro" name="bairro" maxlength="50" required>
            </div>

            <div class="linha-dupla">

                <div class="campo">
                    <label for="cidade">Cidade:</label>
                    <input type="text" id="cidade" name="cidade" maxlength="50" required>
                </div>

                <div class="campo">
                    <label for="uf">UF:</label>
                    <input type="text" id="uf" name="uf" class="uf" maxlength="2" minlength="2" placeholder="SP"
                        required>
                </div>

            </div>

            <div class="campo">
                <label for="cep">CEP:</label>
                <input type="text" id="cep" name="cep" maxlength="8" minlength="8"
                    placeholder="Somente números (8 dígitos)" required>
            </div>

            <button class="botao-cadastrar" type="submit">
                Criar minha conta
            </button>

            <button class="botao-limpar" type="reset">
                Limpar formulário
            </button>

            <a class="link-login" href="home.php">
                Já possui uma conta? Fazer login
            </a>

        </form>

    </main>

</body>

</html>