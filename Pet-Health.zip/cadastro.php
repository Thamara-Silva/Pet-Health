
<?php

session_start();

date_default_timezone_set('America/Sao_Paulo');

if (
    !isset($_SESSION['id_usuario']) ||
    ($_SESSION['status'] ?? '') !== 'CLIENTE'
) {
    header('Location: home.php');
    exit;
}

require 'conexao.php';

$idUsuario = (int) $_SESSION['id_usuario'];
$mensagem = '';
$tipoMensagem = '';

$stmtAnimais = $pdo->prepare("
    SELECT id_animal, nome_animal, especie_animal
    FROM ANIMAIS
    WHERE id_usuario_fk = ?
    ORDER BY nome_animal
");
$stmtAnimais->execute([$idUsuario]);
$animais = $stmtAnimais->fetchAll(PDO::FETCH_ASSOC);

$stmtEspecialidades = $pdo->query("
    SELECT id_especialidade, nome_especialidade, valor_especialidade
    FROM ESPECIALIDADES
    ORDER BY nome_especialidade
");
$especialidades = $stmtEspecialidades->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $idAnimal = filter_input(INPUT_POST, 'id_animal', FILTER_VALIDATE_INT);
    $idEspecialidade = filter_input(INPUT_POST, 'id_especialidade', FILTER_VALIDATE_INT);
    $data = trim($_POST['data_consulta'] ?? '');
    $horario = trim($_POST['horario_consulta'] ?? '');
    $sintomas = trim($_POST['descricao_sintomas'] ?? '');

    if (!$idAnimal || !$idEspecialidade || $data === '' || $horario === '' || $sintomas === '') {

        $mensagem = 'Preencha todos os campos para continuar.';
        $tipoMensagem = 'erro';

    } elseif (
        !preg_match('/^\d{4}-\d{2}-\d{2}$/', $data) ||
        !preg_match('/^\d{2}:\d{2}$/', $horario)
    ) {

        $mensagem = 'Data ou horário inválido.';
        $tipoMensagem = 'erro';

    } else {

        $dataObj = DateTime::createFromFormat('!Y-m-d', $data);
        $dataHora = DateTime::createFromFormat('!Y-m-d H:i', "$data $horario");
        $agora = new DateTime();

        if (
            !$dataObj ||
            $dataObj->format('Y-m-d') !== $data ||
            !$dataHora ||
            $dataHora <= $agora
        ) {

            $mensagem = 'Escolha uma data e um horário futuros.';
            $tipoMensagem = 'erro';

        } else {

            $stmtAnimal = $pdo->prepare("
                SELECT id_animal
                FROM ANIMAIS
                WHERE id_animal = ?
                  AND id_usuario_fk = ?
                LIMIT 1
            ");
            $stmtAnimal->execute([$idAnimal, $idUsuario]);

            $stmtEspecialidade = $pdo->prepare("
                SELECT valor_especialidade
                FROM ESPECIALIDADES
                WHERE id_especialidade = ?
                LIMIT 1
            ");
            $stmtEspecialidade->execute([$idEspecialidade]);
            $especialidade = $stmtEspecialidade->fetch(PDO::FETCH_ASSOC);

            if (!$stmtAnimal->fetch(PDO::FETCH_ASSOC)) {

                $mensagem = 'O animal selecionado não pertence à sua conta.';
                $tipoMensagem = 'erro';

            } elseif (!$especialidade) {

                $mensagem = 'A especialidade selecionada não foi encontrada.';
                $tipoMensagem = 'erro';

            } else {

                $dataHoraSql = $dataHora->format('Y-m-d H:i:s');
                $horaInicio = $dataHora->format('H:i:s');
                $horaFim = (clone $dataHora)->modify('+1 hour')->format('H:i:s');
                $diaSemana = (int) $dataHora->format('N');

                try {

                    $pdo->beginTransaction();

                    $stmtDisponibilidades = $pdo->prepare("
                        SELECT
                            d.id_disponibilidade,
                            v.id_veterinario
                        FROM DISPONIBILIDADE_VETERINARIOS d
                        INNER JOIN VETERINARIOS v
                            ON v.id_veterinario = d.id_veterinario_fk
                        WHERE d.ativo = 1
                          AND d.dia_semana = ?
                          AND d.hora_inicio <= ?
                          AND d.hora_fim >= ?
                          AND v.id_especialidade_fk = ?
                        ORDER BY v.id_veterinario
                        FOR UPDATE
                    ");

                    $stmtDisponibilidades->execute([
                        $diaSemana,
                        $horaInicio,
                        $horaFim,
                        $idEspecialidade
                    ]);

                    $disponibilidades = $stmtDisponibilidades->fetchAll(PDO::FETCH_ASSOC);

                    $idVeterinarioEscolhido = null;

                    $stmtConflito = $pdo->prepare("
                        SELECT id_consulta
                        FROM CONSULTAS
                        WHERE id_veterinario_fk = ?
                          AND STATUS IN ('AGENDADA', 'CONFIRMADA')
                          AND data_consulta < DATE_ADD(?, INTERVAL 1 HOUR)
                          AND DATE_ADD(data_consulta, INTERVAL 1 HOUR) > ?
                        LIMIT 1
                        FOR UPDATE
                    ");

                    foreach ($disponibilidades as $disponibilidade) {

                        $idVeterinario = (int) $disponibilidade['id_veterinario'];

                        $stmtConflito->execute([
                            $idVeterinario,
                            $dataHoraSql,
                            $dataHoraSql
                        ]);

                        if (!$stmtConflito->fetch(PDO::FETCH_ASSOC)) {
                            $idVeterinarioEscolhido = $idVeterinario;
                            break;
                        }
                    }

                    if ($idVeterinarioEscolhido === null) {

                        $pdo->rollBack();

                        $mensagem = 'Esse horário não está mais disponível. Escolha outro horário.';
                        $tipoMensagem = 'erro';

                    } else {

                        $stmtInsert = $pdo->prepare("
                            INSERT INTO CONSULTAS (
                                id_usuario_fk,
                                id_animal_fk,
                                id_veterinario_fk,
                                id_especialidade_fk,
                                descricao_sintomas,
                                data_consulta,
                                valor_total,
                                STATUS
                            )
                            VALUES (?, ?, ?, ?, ?, ?, ?, 'AGENDADA')
                        ");

                        $stmtInsert->execute([
                            $idUsuario,
                            $idAnimal,
                            $idVeterinarioEscolhido,
                            $idEspecialidade,
                            $sintomas,
                            $dataHoraSql,
                            $especialidade['valor_especialidade']
                        ]);

                        $pdo->commit();

                        $mensagem = 'Consulta agendada com sucesso! Você já pode acompanhar sua solicitação em Minhas Consultas.';
                        $tipoMensagem = 'sucesso';

                        $_POST = [];
                    }

                } catch (PDOException $e) {

                    if ($pdo->inTransaction()) {
                        $pdo->rollBack();
                    }

                    error_log($e->getMessage());

                    $mensagem = 'Não foi possível concluir o agendamento. Tente novamente.';
                    $tipoMensagem = 'erro';
                }
            }
        }
    }
}

$hoje = date('Y-m-d');

?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Nova Consulta | Pet Health</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link href="https://fonts.googleapis.com/css2?family=Coiny&family=Nunito:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Nunito', sans-serif;
        }

        body {
            min-height: 100vh;
            padding: 35px 15px;
            display: flex;
            justify-content: center;
            align-items: center;

            background:
                linear-gradient(
                    rgba(118, 85, 163, 0.76),
                    rgba(185, 154, 222, 0.78)
                ),
                url('./imgs/fundo.png');

            background-size: cover;
            background-position: center;
            background-attachment: fixed;
        }

        .container {
            width: 100%;
            max-width: 620px;
            background: rgba(255, 255, 255, 0.97);
            padding: 40px 45px;
            border-radius: 25px;
            box-shadow: 0 15px 45px rgba(65, 40, 85, 0.23);
            border: 1px solid rgba(255, 255, 255, 0.7);
        }

        /* Cabeçalho */

        .logo {
            text-align: center;
            font-family: 'Coiny', cursive;
            font-size: 34px;
            color: #7655a3;
            margin-bottom: 5px;
        }

        .logo span {
            font-family: 'Coiny', cursive;
            color: #ef713f;
        }

        .subtitulo {
            text-align: center;
            color: #91859d;
            font-size: 14px;
            margin-bottom: 28px;
            line-height: 1.5;
        }

        /* Mensagens */

        .mensagem {
            text-align: center;
            font-size: 14px;
            font-weight: 800;
            padding: 13px;
            border-radius: 12px;
            margin-bottom: 20px;
            line-height: 1.5;
        }

        .mensagem.erro {
            color: #a03535;
            background: #fde8e8;
            border: 1px solid #f5b5b5;
        }

        .mensagem.sucesso {
            color: #2c6e3a;
            background: #e6f7eb;
            border: 1px solid #b7e3c2;
        }

        /* Aviso */

        .aviso {
            background: #fff4ed;
            border-left: 4px solid #ef713f;
            padding: 15px;
            border-radius: 10px;
            font-size: 14px;
            color: #a0573a;
            margin-bottom: 22px;
            line-height: 1.6;
        }

        .aviso a {
            color: #ef713f;
            font-weight: 800;
        }

        /* Seções */

        .secao-titulo {
            color: #7655a3;
            font-size: 16px;
            font-weight: 800;
            margin: 25px 0 17px;
            padding-bottom: 9px;
            border-bottom: 2px solid #eee6f5;
        }

        .descricao-secao {
            color: #91859d;
            font-size: 13px;
            margin-top: -10px;
            margin-bottom: 18px;
        }

        /* Campos */

        .input-box {
            width: 100%;
            margin-bottom: 19px;
        }

        .input-box label {
            display: block;
            color: #594176;
            font-size: 14px;
            font-weight: 800;
            margin-bottom: 8px;
        }

        .input-box input,
        .input-box select,
        .input-box textarea {
            width: 100%;
            padding: 13px 15px;
            border: 2px solid #e6dcef;
            border-radius: 11px;
            outline: none;
            background: #fcfaff;
            color: #493d52;
            font-size: 14px;
            transition: 0.2s;
        }

        .input-box input,
        .input-box select {
            height: 49px;
        }

        .input-box textarea {
            min-height: 125px;
            resize: vertical;
            line-height: 1.5;
        }

        .input-box input:focus,
        .input-box select:focus,
        .input-box textarea:focus {
            border-color: #8e6bbe;
            background: white;
            box-shadow: 0 0 0 3px rgba(142, 107, 190, 0.12);
        }

        .input-box input::placeholder,
        .input-box textarea::placeholder {
            color: #aa9bb3;
        }

        /* Valor */

        .valor {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 12px;
            background: #f7f1ff;
            border: 1px solid #e5dced;
            border-radius: 12px;
            padding: 15px;
            color: #594176;
            font-size: 14px;
            margin-top: -5px;
            margin-bottom: 23px;
        }

        .valor strong {
            color: #ef713f;
            font-size: 18px;
            white-space: nowrap;
        }

        .ajuda-horario {
            color: #91859d;
            font-size: 12px;
            margin-top: 7px;
            line-height: 1.5;
        }

        /* Botões */

        .botao-agendar {
            width: 100%;
            border: none;
            border-radius: 12px;
            padding: 15px;
            background: linear-gradient(90deg, #ef713f, #f28b62);
            color: white;
            font-size: 16px;
            font-weight: 800;
            cursor: pointer;
            transition: 0.2s;
            margin-top: 8px;
            box-shadow: 0 5px 12px rgba(239, 113, 63, 0.2);
        }

        .botao-agendar:hover:not(:disabled) {
            background: linear-gradient(90deg, #dc5f2f, #e97950);
            transform: translateY(-2px);
            box-shadow: 0 8px 18px rgba(239, 113, 63, 0.25);
        }

        .botao-agendar:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }

        .voltar {
            display: block;
            text-align: center;
            margin-top: 17px;
            padding: 12px;
            border-radius: 11px;
            text-decoration: none;
            color: #7655a3;
            background: #f3edfa;
            font-size: 14px;
            font-weight: 800;
            transition: 0.2s;
        }

        .voltar:hover {
            background: #e6d9f3;
            color: #594176;
        }

        /* Responsividade */

        @media (max-width: 550px) {
            .container {
                padding: 28px 22px;
                border-radius: 20px;
            }

            .logo {
                font-size: 29px;
            }

            .valor {
                align-items: flex-start;
                flex-direction: column;
                gap: 5px;
            }
        }
    </style>
</head>

<body>

    <main class="container">

        <h1 class="logo">Pet <span>Health</span></h1>

        <p class="subtitulo">
            Agende um atendimento para seu melhor amigo!
        </p>

        <?php if ($mensagem !== ''): ?>

            <div class="mensagem <?= htmlspecialchars($tipoMensagem, ENT_QUOTES, 'UTF-8') ?>">
                <?= htmlspecialchars($mensagem, ENT_QUOTES, 'UTF-8') ?>
            </div>

        <?php endif; ?>

        <?php if (empty($animais)): ?>

            <div class="aviso">
                Você ainda não possui animais cadastrados.
                Cadastre seu pet em
                <a href="meus_animais.php">Meus Animais</a>
                antes de agendar uma consulta.
            </div>

        <?php else: ?>

            <form method="POST" id="formConsulta">

                <h2 class="secao-titulo">🐾 Dados do atendimento</h2>

                <div class="input-box">
                    <label for="id_animal">Qual animal precisa de atendimento?</label>

                    <select id="id_animal" name="id_animal" required>
                        <option value="">Selecione seu pet</option>

                        <?php foreach ($animais as $animal): ?>

                            <option
                                value="<?= (int) $animal['id_animal'] ?>"
                                <?= (($_POST['id_animal'] ?? '') == $animal['id_animal']) ? 'selected' : '' ?>
                            >
                                <?= htmlspecialchars($animal['nome_animal'], ENT_QUOTES, 'UTF-8') ?>

                                <?php if (!empty($animal['especie_animal'])): ?>
                                    - <?= htmlspecialchars($animal['especie_animal'], ENT_QUOTES, 'UTF-8') ?>
                                <?php endif; ?>
                            </option>

                        <?php endforeach; ?>

                    </select>
                </div>

                <div class="input-box">
                    <label for="id_especialidade">Especialidade</label>

                    <select id="id_especialidade" name="id_especialidade" required>
                        <option value="">Selecione uma especialidade</option>

                        <?php foreach ($especialidades as $esp): ?>

                            <option
                                value="<?= (int) $esp['id_especialidade'] ?>"
                                data-valor="<?= htmlspecialchars((string) $esp['valor_especialidade'], ENT_QUOTES, 'UTF-8') ?>"
                                <?= (($_POST['id_especialidade'] ?? '') == $esp['id_especialidade']) ? 'selected' : '' ?>
                            >
                                <?= htmlspecialchars($esp['nome_especialidade'], ENT_QUOTES, 'UTF-8') ?>
                            </option>

                        <?php endforeach; ?>

                    </select>
                </div>

                <div class="valor">
                    <span>Valor da consulta</span>
                    <strong id="valorConsulta">Selecione uma especialidade</strong>
                </div>

                <h2 class="secao-titulo">📅 Data e horário</h2>

                <p class="descricao-secao">
                    Escolha uma data e consulte os horários disponíveis.
                </p>

                <div class="input-box">
                    <label for="data_consulta">Data da consulta</label>

                    <input
                        type="date"
                        id="data_consulta"
                        name="data_consulta"
                        min="<?= $hoje ?>"
                        value="<?= htmlspecialchars($_POST['data_consulta'] ?? '', ENT_QUOTES, 'UTF-8') ?>"
                        required
                    >
                </div>

                <div class="input-box">
                    <label for="horario_consulta">Horário disponível</label>

                    <select
                        id="horario_consulta"
                        name="horario_consulta"
                        required
                        disabled
                    >
                        <option value="">Selecione primeiro a especialidade e a data</option>
                    </select>

                    <p class="ajuda-horario" id="ajudaHorario">
                        Os horários serão carregados conforme a disponibilidade dos veterinários.
                        Cada consulta dura uma hora.
                    </p>
                </div>

                <h2 class="secao-titulo">📝 Informações sobre o pet</h2>

                <div class="input-box">
                    <label for="descricao_sintomas">Descrição dos sintomas</label>

                    <textarea
                        id="descricao_sintomas"
                        name="descricao_sintomas"
                        placeholder="Descreva o que seu animal está sentindo..."
                        required
                    ><?= htmlspecialchars($_POST['descricao_sintomas'] ?? '', ENT_QUOTES, 'UTF-8') ?></textarea>
                </div>

                <button type="submit" class="botao-agendar" id="btnAgendar">
                    Agendar consulta
                </button>

            </form>

        <?php endif; ?>

        <a href="cliente.php" class="voltar">
            ← Voltar para a área do cliente
        </a>

    </main>

    <script>
        const especialidade = document.getElementById('id_especialidade');
        const dataConsulta = document.getElementById('data_consulta');
        const horarioConsulta = document.getElementById('horario_consulta');
        const valorConsulta = document.getElementById('valorConsulta');
        const ajudaHorario = document.getElementById('ajudaHorario');

        function atualizarValor() {

            if (!especialidade) return;

            const opcao = especialidade.options[especialidade.selectedIndex];

            if (!opcao || !opcao.dataset.valor) {
                valorConsulta.textContent = 'Selecione uma especialidade';
                return;
            }

            const valor = Number(opcao.dataset.valor);

            valorConsulta.textContent = valor.toLocaleString('pt-BR', {
                style: 'currency',
                currency: 'BRL'
            });
        }

        async function carregarHorarios() {

            if (!especialidade || !dataConsulta) return;

            const idEspecialidade = especialidade.value;
            const data = dataConsulta.value;

            horarioConsulta.innerHTML = '<option value="">Carregando horários...</option>';
            horarioConsulta.disabled = true;

            if (!idEspecialidade || !data) {

                horarioConsulta.innerHTML = '<option value="">Selecione primeiro a especialidade e a data</option>';

                ajudaHorario.textContent =
                    'Os horários serão carregados conforme a disponibilidade dos veterinários.';

                return;
            }

            try {

                const parametros = new URLSearchParams({
                    id_especialidade: idEspecialidade,
                    data: data
                });

                const resposta = await fetch(
                    'horarios_disponiveis.php?' + parametros.toString()
                );

                const resultado = await resposta.json();

                horarioConsulta.innerHTML = '';

                if (!resposta.ok || !resultado.sucesso) {

                    horarioConsulta.innerHTML =
                        '<option value="">Não foi possível carregar os horários</option>';

                    ajudaHorario.textContent =
                        resultado.mensagem || 'Tente novamente.';

                    return;
                }

                if (resultado.horarios.length === 0) {

                    horarioConsulta.innerHTML =
                        '<option value="">Nenhum horário disponível</option>';

                    ajudaHorario.textContent =
                        'Não há horários livres para essa especialidade nessa data. Escolha outro dia.';

                    return;
                }

                horarioConsulta.innerHTML =
                    '<option value="">Selecione um horário</option>';

                resultado.horarios.forEach(horario => {

                    const opcao = document.createElement('option');

                    opcao.value = horario;
                    opcao.textContent = horario;

                    horarioConsulta.appendChild(opcao);
                });

                horarioConsulta.disabled = false;

                ajudaHorario.textContent =
                    'Cada consulta tem duração de uma hora.';

                <?php if (!empty($_POST['horario_consulta'])): ?>

                    horarioConsulta.value =
                        <?= json_encode($_POST['horario_consulta']) ?>;

                <?php endif; ?>

            } catch (erro) {

                horarioConsulta.innerHTML =
                    '<option value="">Erro ao carregar horários</option>';

                ajudaHorario.textContent =
                    'Verifique sua conexão e tente novamente.';
            }
        }

        if (especialidade) {

            especialidade.addEventListener('change', () => {
                atualizarValor();
                carregarHorarios();
            });
        }

        if (dataConsulta) {
            dataConsulta.addEventListener('change', carregarHorarios);
        }

        atualizarValor();

        if (
            especialidade &&
            dataConsulta &&
            especialidade.value &&
            dataConsulta.value
        ) {
            carregarHorarios();
        }
    </script>

</body>

</html>
