
<?php

session_start();

// Proteção: somente administradores podem acessar.
if (
    !isset($_SESSION['id_usuario']) ||
    !isset($_SESSION['status']) ||
    $_SESSION['status'] !== 'ADMINISTRADOR'
) {
    header('Location: home.php');
    exit;
}

// Importa a conexão com o banco de dados.
require_once 'conexao.php';

// Busca as consultas cadastradas.
try {
    $sql = "SELECT
            c.id_consulta,
            c.id_animal_fk,
            a.nome_animal,
            c.descricao_sintomas,
            c.data_consulta,
            c.valor_total,
            c.STATUS
        FROM CONSULTAS c
        LEFT JOIN ANIMAIS a
            ON c.id_animal_fk = a.id_animal
        ORDER BY c.data_consulta DESC";

    $stmt = $pdo->query($sql);
    $consultas = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    error_log($e->getMessage());
    $erro = true;
}

// Prepara uma função para exibir textos com segurança.
function limparTexto($texto)
{
    return htmlspecialchars(
        (string) ($texto ?? ''),
        ENT_QUOTES,
        'UTF-8'
    );
}

?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Consultas | Pet Health</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Coiny&family=Nunito:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Nunito', sans-serif;
        }

        body {
            min-height: 100vh;
            background: linear-gradient(135deg, #f7f1ff, #e9dcfa, #fff4ed);
            color: #594176;
            padding: 30px 5%;
        }

        /* Cabeçalho */

        header {
            background: #ffffff;
            padding: 18px 25px;
            border-radius: 16px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
            margin-bottom: 28px;
            box-shadow: 0 5px 20px rgba(118, 85, 163, 0.08);
        }

        header h1 {
            font-family: 'Coiny', cursive;
            font-size: 25px;
            font-weight: normal;
            color: #7655a3;
        }

        header h1 span {
            color: #ef713f;
            font-family: 'Coiny', cursive;
        }

        .voltar {
            background: #ef713f;
            color: white;
            padding: 11px 19px;
            text-decoration: none;
            border-radius: 10px;
            font-weight: 800;
            font-size: 14px;
            transition: 0.2s;
        }

        .voltar:hover {
            background: #dc6031;
            transform: translateY(-2px);
        }

        /* Conteúdo */

        .conteudo {
            background: #ffffff;
            padding: 30px;
            border-radius: 18px;
            box-shadow: 0 8px 25px rgba(118, 85, 163, 0.08);
        }

        h2 {
            font-family: 'Coiny', cursive;
            font-weight: normal;
            font-size: 25px;
            color: #7655a3;
            margin-bottom: 8px;
        }

        .descricao {
            color: #776985;
            margin-bottom: 23px;
            line-height: 1.6;
            font-size: 14px;
        }

        /* Resumo */

        .resumo {
            background: #f7f1ff;
            border-left: 4px solid #ef713f;
            padding: 16px 18px;
            border-radius: 10px;
            margin-bottom: 23px;
            color: #66547b;
            font-size: 14px;
        }

        .resumo strong {
            color: #7655a3;
            font-size: 17px;
        }

        /* Tabela */

        .tabela-container {
            overflow-x: auto;
            border-radius: 12px;
            border: 1px solid #eee5f7;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 750px;
        }

        th,
        td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #eee8f5;
            font-size: 14px;
        }

        th {
            background: #f3edfa;
            color: #7655a3;
            font-weight: 800;
        }

        td {
            color: #665b70;
        }

        tbody tr:hover {
            background: #fcf9ff;
        }

        tbody tr:last-child td {
            border-bottom: none;
        }

        /* Status */

        .status {
            display: inline-block;
            padding: 6px 11px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 800;
            white-space: nowrap;
        }

        .agendada {
            background: #fff0df;
            color: #c66b1c;
        }

        .confirmada {
            background: #e4f6e9;
            color: #27834a;
        }

        .cancelada {
            background: #ffe8e8;
            color: #c03939;
        }

        .atendido {
            background: #eee6fa;
            color: #7655a3;
        }

        .status-padrao {
            background: #f0edf3;
            color: #776985;
        }

        /* Mensagens */

        .vazio {
            text-align: center;
            padding: 30px;
            color: #91859d;
        }

        .erro {
            color: #b42318;
            background: #fff0ee;
            padding: 16px;
            border-radius: 10px;
            border-left: 4px solid #d92d20;
            font-size: 14px;
        }

        /* Rodapé */

        footer {
            text-align: center;
            padding: 25px 10px 5px;
            color: #91859d;
            font-size: 13px;
        }

        @media (max-width: 600px) {
            body {
                padding: 15px;
            }

            header {
                padding: 18px;
            }

            header h1 {
                font-size: 21px;
            }

            .conteudo {
                padding: 20px 15px;
            }

            h2 {
                font-size: 22px;
            }

            .voltar {
                width: 100%;
                text-align: center;
            }
        }
    </style>
</head>

<body>

    <header>
        <h1>Pet <span>Health</span> | Consultas</h1>

        <a class="voltar" href="admin.php">
            Voltar ao painel
        </a>
    </header>

    <main class="conteudo">

        <h2>Consultas cadastradas</h2>

        <p class="descricao">
            Confira as informações das consultas registradas no sistema.
        </p>

        <?php if (isset($erro)): ?>

            <p class="erro">
                Não foi possível carregar as consultas.
                Tente novamente mais tarde.
            </p>

        <?php else: ?>

            <p class="resumo">
                Total de consultas encontradas:
                <strong><?= count($consultas) ?></strong>
            </p>

            <div class="tabela-container">

                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Animal</th>
                            <th>Sintomas</th>
                            <th>Data</th>
                            <th>Valor</th>
                            <th>Status</th>
                        </tr>
                    </thead>

                    <tbody>

                        <?php if (count($consultas) > 0): ?>

                            <?php foreach ($consultas as $consulta): ?>

                                <tr>
                                    <td>
                                        <?= limparTexto($consulta['id_consulta']) ?>
                                    </td>

                                    <td>
                                        <?= limparTexto($consulta['nome_animal'] ?? 'Animal não encontrado') ?>
                                    </td>

                                    <td>
                                        <?= limparTexto($consulta['descricao_sintomas']) ?>
                                    </td>

                                    <td>
                                        <?= limparTexto($consulta['data_consulta']) ?>
                                    </td>

                                    <td>
                                        <?= $consulta['valor_total'] !== null
                                            ? 'R$ ' . number_format((float) $consulta['valor_total'], 2, ',', '.')
                                            : 'Não informado' ?>
                                    </td>

                                    <td>
                                        <?php
                                        $status = $consulta['STATUS'] ?? '';
                                        $classeStatus = match ($status) {
                                            'AGENDADA' => 'agendada',
                                            'CONFIRMADA' => 'confirmada',
                                            'CANCELADA' => 'cancelada',
                                            'ATENDIDO' => 'atendido',
                                            default => 'status-padrao'
                                        };
                                        ?>

                                        <span class="status <?= $classeStatus ?>">
                                            <?= limparTexto($status ?: 'Não informado') ?>
                                        </span>
                                    </td>
                                </tr>

                            <?php endforeach; ?>

                        <?php else: ?>

                            <tr>
                                <td colspan="6" class="vazio">
                                    Nenhuma consulta cadastrada ainda.
                                </td>
                            </tr>

                        <?php endif; ?>

                    </tbody>
                </table>

            </div>

        <?php endif; ?>

    </main>

    <footer>
        © 2026 Pet Health — Cuidando de quem faz parte da sua família.
    </footer>

</body>
</html>
