
<?php
session_start();

date_default_timezone_set('America/Sao_Paulo');

header('Content-Type: application/json; charset=utf-8');

// Apenas clientes logados podem consultar os horários
if (
    !isset($_SESSION['id_usuario']) ||
    ($_SESSION['status'] ?? '') !== 'CLIENTE'
) {
    http_response_code(403);
    echo json_encode([
        'sucesso' => false,
        'mensagem' => 'Acesso não autorizado.'
    ]);
    exit;
}

require 'conexao.php';

$idEspecialidade = filter_input(INPUT_GET, 'id_especialidade', FILTER_VALIDATE_INT);
$data = trim($_GET['data'] ?? '');

if (
    !$idEspecialidade ||
    !preg_match('/^\d{4}-\d{2}-\d{2}$/', $data)
) {
    http_response_code(400);
    echo json_encode([
        'sucesso' => false,
        'mensagem' => 'Especialidade ou data inválida.'
    ]);
    exit;
}

$dataObj = DateTime::createFromFormat('!Y-m-d', $data);

if (!$dataObj || $dataObj->format('Y-m-d') !== $data || $data < date('Y-m-d')) {
    http_response_code(400);
    echo json_encode([
        'sucesso' => false,
        'mensagem' => 'Escolha uma data válida, a partir de hoje.'
    ]);
    exit;
}

try {

    // Número do dia da semana: segunda = 1, domingo = 7
    $diaSemana = (int) $dataObj->format('N');

    // Busca as disponibilidades dos veterinários da especialidade
    $stmt = $pdo->prepare("
        SELECT
            d.hora_inicio,
            d.hora_fim,
            v.id_veterinario
        FROM DISPONIBILIDADE_VETERINARIOS d
        INNER JOIN VETERINARIOS v
            ON v.id_veterinario = d.id_veterinario_fk
        WHERE d.ativo = 1
          AND d.dia_semana = ?
          AND v.id_especialidade_fk = ?
        ORDER BY d.hora_inicio, v.id_veterinario
    ");

    $stmt->execute([$diaSemana, $idEspecialidade]);
    $disponibilidades = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $horariosLivres = [];

    // Verifica se cada horário de uma hora está livre
    $stmtConflito = $pdo->prepare("
        SELECT id_consulta
        FROM CONSULTAS
        WHERE id_veterinario_fk = ?
          AND STATUS IN ('AGENDADA', 'CONFIRMADA')
          AND data_consulta < DATE_ADD(?, INTERVAL 1 HOUR)
          AND DATE_ADD(data_consulta, INTERVAL 1 HOUR) > ?
        LIMIT 1
    ");

    foreach ($disponibilidades as $disponibilidade) {

        $inicio = new DateTime($data . ' ' . $disponibilidade['hora_inicio']);
        $fim = new DateTime($data . ' ' . $disponibilidade['hora_fim']);

        // Cada horário começa uma hora depois do anterior
        while (true) {

            $finalConsulta = (clone $inicio)->modify('+1 hour');

            // A consulta precisa terminar dentro da disponibilidade
            if ($finalConsulta > $fim) {
                break;
            }

            // Não oferece horários que já passaram
            if ($inicio > new DateTime()) {

                $dataHora = $inicio->format('Y-m-d H:i:s');

                $stmtConflito->execute([
                    $disponibilidade['id_veterinario'],
                    $dataHora,
                    $dataHora
                ]);

                if (!$stmtConflito->fetch(PDO::FETCH_ASSOC)) {
                    $horario = $inicio->format('H:i');

                    // Evita repetir o horário quando há mais de um veterinário livre
                    $horariosLivres[$horario] = $horario;
                }
            }

            $inicio->modify('+1 hour');
        }
    }

    $horarios = array_values($horariosLivres);
    sort($horarios);

    echo json_encode([
        'sucesso' => true,
        'horarios' => $horarios
    ]);

} catch (PDOException $e) {

    error_log($e->getMessage());

    http_response_code(500);

    echo json_encode([
        'sucesso' => false,
        'mensagem' => 'Erro ao consultar os horários disponíveis.'
    ]);
}
