<?php

session_start();

require_once 'conexao.php';

/* 1. Verifica se o formulário foi enviado. */
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: home.php');
    exit;
}

/* 2. Recebe os dados digitados no formulário. */
$email = trim($_POST['email_usuario'] ?? '');
$senha = $_POST['senha_usuario'] ?? '';

/* 3. Verifica se os campos foram preenchidos. */
if ($email === '' || $senha === '') {
    header('Location: home.php?erro=1');
    exit;
}

try {

    /* 4. Busca o usuário pelo e-mail. */
    $sql = "SELECT
                id_usuario,
                nome_usuario,
                email_usuario,
                senha_usuario,
                STATUS
            FROM USUARIOS
            WHERE email_usuario = ?
            LIMIT 1";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([$email]);

    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

    /* 5. Confere se o usuário existe e se a senha está correta. */
    if (
        !$usuario ||
        !password_verify($senha, $usuario['senha_usuario'])
    ) {
        header('Location: home.php?erro=1');
        exit;
    }

    /* 6. Cria uma nova identificação de sessão após o login. */
    session_regenerate_id(true);

    $_SESSION['id_usuario'] = $usuario['id_usuario'];
    $_SESSION['nome_usuario'] = $usuario['nome_usuario'];
    $_SESSION['email_usuario'] = $usuario['email_usuario'];
    $_SESSION['status'] = $usuario['STATUS'];

    /* 7. Direciona cada tipo de usuário para sua página. */
    if ($usuario['STATUS'] === 'ADMINISTRADOR') {

        header('Location: admin.php');

    } elseif ($usuario['STATUS'] === 'VETERINARIO') {

        header('Location: veterinario.php');

    } elseif ($usuario['STATUS'] === 'CLIENTE') {

        header('Location: cliente.php');

    } else {

        /* Impede o acesso se o tipo de conta não for reconhecido. */
        session_unset();
        session_destroy();

        header('Location: home.php?erro=1');
    }

    exit;

} catch (PDOException $e) {

    error_log($e->getMessage());

    http_response_code(500);
    echo 'Erro ao realizar login. Tente novamente.';
    exit;
}