<?php

$host = "sql305.infinityfree.com";   
$porta = "3306";      
$usuario = "if0_43482746";
$senha = "EqZRTvnsgzjbDdX";
$banco = "if0_43482746_pet_health";

try {
    $pdo = new PDO(
        "mysql:host=$host;port=$porta;dbname=$banco;charset=utf8mb4",
        $usuario,
        $senha,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );
} catch (PDOException $e) {
    die("Erro de conexão: " . $e->getMessage());
}