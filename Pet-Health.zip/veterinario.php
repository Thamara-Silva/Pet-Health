
<?php
session_start();

// 1. Proteção: apenas VETERINARIO logado
if (
    !isset($_SESSION['id_usuario']) ||
    ($_SESSION['status'] ?? '') !== 'VETERINARIO'
) {
    header('Location: home.php');
    exit;
}

require 'conexao.php';

$idUsuario = (int) $_SESSION['id_usuario'];

// 2. Descobre os dados do veterinário
$stmtVet = $pdo->prepare("
    SELECT
        id_veterinario,
        nome_veterinario,
        id_especialidade_fk
    FROM VETERINARIOS
    WHERE id_usuario_fk = ?
    LIMIT 1
");

$stmtVet->execute([$idUsuario]);
$veterinario = $stmtVet->fetch(PDO::FETCH_ASSOC);

if (!$veterinario) {
    http_response_code(403);
    echo 'Conta de veterinário sem registro profissional. Contate o administrador.';
    exit;
}

$idVeterinario = (int) $veterinario['id_veterinario'];

$mensagem = '';
$tipoMensagem = '';

// 3. Processa atualização do status
if (
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    isset($_POST['atualizar_id'])
) {

    $idConsulta = filter_input(
        INPUT_POST,
        'atualizar_id',
        FILTER_VALIDATE_INT
    );

    $novoStatus = trim($_POST['status'] ?? '');

    $statusPermitidos = [
        'AGENDADA',
        'CONFIRMADA',
        'CANCELADA',
        'ATENDIDO'
    ];

    if (
        !$idConsulta ||
        !in_array($novoStatus, $statusPermitidos, true)
    ) {
        $mensagem = 'Dados inválidos. Verifique o status selecionado.';
        $tipoMensagem = 'erro';

    } else {

        try {

            // Confirma que a consulta pertence a este veterinário
            $stmtConsulta = $pdo->prepare("
                SELECT id_consulta
                FROM CONSULTAS
                WHERE id_consulta = ?
                  AND id_veterinario_fk = ?
                LIMIT 1
            ");

            $stmtConsulta->execute([
                $idConsulta,
                $idVeterinario
            ]);

            $consultaExiste = $stmtConsulta->fetch(PDO::FETCH_ASSOC);

            if (!$consultaExiste) {

                $mensagem = 'Consulta não encontrada ou não pertence a você.';
                $tipoMensagem = 'erro';

            } else {

                // Atualiza somente o status
                $stmtUpdate = $pdo->prepare("
                    UPDATE CONSULTAS
                    SET STATUS = ?
                    WHERE id_consulta = ?
                      AND id_veterinario_fk = ?
                ");

                $stmtUpdate->execute([
                    $novoStatus,
                    $idConsulta,
                    $idVeterinario
                ]);

                $mensagem = 'Status da consulta atualizado com sucesso!';
                $tipoMensagem = 'sucesso';
            }

        } catch (PDOException $e) {

            error_log($e->getMessage());

            $mensagem = 'Erro ao atualizar a consulta. Tente novamente.';
            $tipoMensagem = 'erro';
        }
    }
}

// 4. Lista somente as consultas atribuídas a este veterinário
try {

    $stmtList = $pdo->prepare("
        SELECT
            c.id_consulta,
            c.descricao_sintomas,
            c.data_consulta,
            c.valor_total,
            c.STATUS,
            c.id_especialidade_fk,
            a.nome_animal,
            u.nome_usuario AS tutor,
            e.nome_especialidade
        FROM CONSULTAS c
        INNER JOIN ANIMAIS a
            ON a.id_animal = c.id_animal_fk
        INNER JOIN USUARIOS u
            ON u.id_usuario = c.id_usuario_fk
        LEFT JOIN ESPECIALIDADES e
            ON e.id_especialidade = c.id_especialidade_fk
        WHERE c.id_veterinario_fk = ?
        ORDER BY c.data_consulta ASC, c.id_consulta DESC
    ");

    $stmtList->execute([$idVeterinario]);

    $consultas = $stmtList->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {

    error_log($e->getMessage());

    $erro = true;
    $mensagem = 'Erro ao carregar as consultas.';
    $tipoMensagem = 'erro';
}
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel do Veterinário | Pet Health</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link href="https://fonts.googleapis.com/css2?family=Coiny&family=Nunito:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Nunito', sans-serif;
        }

        body {
            min-height: 100vh;
            background: linear-gradient(135deg, #f7f1ff, #e9dcfa, #fff4ed);
            color: #665b70;
        }

        header {
            background: #ffffff;
            padding: 18px 8%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 15px;
            flex-wrap: wrap;
            box-shadow: 0 4px 20px rgba(118, 85, 163, 0.08);
        }

        .texto-logo {
            font-family: 'Coiny', system-ui;
            font-size: 28px;
            color: #7655a3;
        }

        .texto-logo span {
            font-family: 'Coiny', system-ui;
            color: #ef713f;
        }

        .identificacao {
            font-family: 'Nunito', sans-serif;
            font-size: 15px;
            font-weight: 800;
            color: #776985;
        }

        .sair {
            background: #ef713f;
            color: white;
            padding: 11px 22px;
            text-decoration: none;
            border-radius: 11px;
            font-weight: 800;
            font-size: 14px;
            transition: 0.2s;
            box-shadow: 0 4px 10px rgba(239, 113, 63, 0.2);
        }

        .sair:hover {
            background: #dc6031;
            transform: translateY(-2px);
        }

        main {
            width: 90%;
            max-width: 1100px;
            margin: 40px auto;
        }

        .boas-vindas {
            background: #ffffff;
            padding: 28px;
            border-radius: 20px;
            margin-bottom: 25px;
            box-shadow: 0 8px 25px rgba(118, 85, 163, 0.08);
            border-left: 5px solid #ef713f;
        }

        .boas-vindas h2 {
            color: #594176;
            font-family: 'Coiny', system-ui;
            font-weight: normal;
            font-size: 25px;
            margin-bottom: 8px;
        }

        .boas-vindas p {
            color: #776985;
            line-height: 1.7;
            font-size: 15px;
        }

        .mensagem {
            padding: 14px 18px;
            border-radius: 12px;
            margin-bottom: 22px;
            font-weight: 800;
            text-align: center;
        }

        .mensagem.sucesso {
            background: #e6f7eb;
            color: #2c6e3a;
            border: 1px solid #b7e3c2;
        }

        .mensagem.erro {
            background: #fde8e8;
            color: #a03535;
            border: 1px solid #f5b5b5;
        }

        .titulo-consultas {
            font-family: 'Coiny', system-ui;
            font-size: 27px;
            font-weight: normal;
            color: #594176;
            margin-bottom: 20px;
        }

        .grid-consultas {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
            gap: 22px;
        }

        .card-consulta {
            background: #ffffff;
            border-radius: 20px;
            padding: 25px;
            box-shadow: 0 8px 25px rgba(118, 85, 163, 0.08);
            border-top: 5px solid #7655a3;
            transition: 0.3s ease;
            display: flex;
            flex-direction: column;
        }

        .card-consulta.nova {
            border-top-color: #ef713f;
        }

        .card-consulta:hover {
            transform: translateY(-4px);
            box-shadow: 0 12px 30px rgba(118, 85, 163, 0.15);
        }

        .card-consulta h3 {
            font-family: 'Coiny', system-ui;
            font-size: 23px;
            color: #594176;
            margin-bottom: 4px;
            font-weight: normal;
        }

        .tutor {
            color: #91859d;
            font-size: 13px;
            font-weight: 700;
            margin-bottom: 16px;
        }

        .info-linha {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 12px;
            padding: 9px 0;
            border-bottom: 1px solid #f0eaf5;
            font-size: 14px;
            color: #776985;
        }

        .info-linha:last-of-type {
            border-bottom: none;
        }

        .info-linha strong {
            color: #594176;
            text-align: right;
            max-width: 65%;
            overflow-wrap: anywhere;
        }

        .badge {
            display: inline-block;
            padding: 5px 11px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 900;
            white-space: nowrap;
        }

        .badge-pendente {
            background: #fff0e8;
            color: #b5532a;
        }

        .badge-atribuida {
            background: #e8f0fe;
            color: #1a56b0;
        }

        .form-edicao {
            margin-top: 20px;
            padding-top: 20px;
            border-top: 2px dashed #e5dced;
        }

        .form-edicao h4 {
            color: #594176;
            font-family: 'Coiny', system-ui;
            font-size: 18px;
            font-weight: normal;
            margin-bottom: 15px;
        }

        .form-edicao .campo {
            margin-bottom: 14px;
        }

        .form-edicao label {
            display: block;
            font-size: 13px;
            font-weight: 800;
            color: #594176;
            margin-bottom: 6px;
        }

        .form-edicao input,
        .form-edicao select {
            width: 100%;
            padding: 11px 13px;
            border: 1px solid #e5dced;
            border-radius: 10px;
            font-size: 14px;
            background: #fdfbff;
            color: #665b70;
            outline: none;
        }

        .form-edicao input:disabled {
            background: #f6f2fa;
            color: #776985;
            cursor: not-allowed;
            opacity: 1;
        }

        .form-edicao select:focus {
            border-color: #9674c4;
            box-shadow: 0 0 0 3px #9674c422;
        }

        .form-edicao button {
            width: 100%;
            padding: 13px;
            border: none;
            border-radius: 11px;
            background: #ef713f;
            color: white;
            font-weight: 900;
            cursor: pointer;
            font-size: 14px;
            margin-top: 5px;
            transition: 0.2s;
            box-shadow: 0 4px 10px rgba(239, 113, 63, 0.2);
        }

        .form-edicao button:hover {
            background: #dc6031;
            transform: translateY(-2px);
        }

        .msg-vazia {
            background: #ffffff;
            padding: 45px 30px;
            border-radius: 20px;
            text-align: center;
            color: #776985;
            box-shadow: 0 8px 25px rgba(118, 85, 163, 0.08);
        }

        .msg-vazia h3 {
            font-family: 'Coiny', system-ui;
            color: #594176;
            font-weight: normal;
            font-size: 23px;
            margin-bottom: 10px;
        }

        footer {
            text-align: center;
            padding: 25px 15px;
            color: #91859d;
            font-size: 13px;
        }

        @media (max-width: 768px) {
            header {
                flex-direction: column;
                text-align: center;
                padding: 20px;
            }

            main {
                margin: 25px auto;
            }

            .grid-consultas {
                grid-template-columns: 1fr;
            }

            .boas-vindas {
                padding: 22px;
            }
        }

        @media (max-width: 400px) {
            .card-consulta {
                padding: 20px;
            }

            .info-linha {
                font-size: 13px;
            }
        }
    </style>
</head>

<body>

    <header>
        <div class="texto-logo">
            Pet <span>Health</span>
            <span class="identificacao">| Veterinário</span>
        </div>

        <a class="sair" href="logout.php"
           onclick="return confirm('Tem certeza de que deseja sair?');">
            Sair da conta
        </a>
    </header>

    <main>

        <section class="boas-vindas">
            <h2>Olá, Dr(a). <?= htmlspecialchars($veterinario['nome_veterinario']) ?>!</h2>

            <p>
                Acompanhe suas consultas, confira os dados dos atendimentos
                e atualize o status de cada consulta.
            </p>
        </section>

        <?php if ($mensagem !== ''): ?>
            <div class="mensagem <?= htmlspecialchars($tipoMensagem) ?>">
                <?= htmlspecialchars($mensagem) ?>
            </div>
        <?php endif; ?>

        <?php if (isset($erro)): ?>

            <div class="msg-vazia">
                <h3 style="color: #a03535;">Erro ao carregar consultas</h3>
                <p>Tente novamente mais tarde.</p>
            </div>

        <?php elseif (count($consultas) === 0): ?>

            <div class="msg-vazia">
                <h3>Nenhuma consulta no momento</h3>
                <p>Não há solicitações pendentes nem consultas atribuídas a você.</p>
            </div>

        <?php else: ?>

            <h2 class="titulo-consultas">Minhas consultas</h2>

            <div class="grid-consultas">

                <?php foreach ($consultas as $c): ?>

                    <?php
                    $pendente = empty($c['data_consulta']) || empty($c['id_especialidade_fk']);
                    $dataAtual = '';

                    if (!empty($c['data_consulta'])) {
                        $dt = DateTime::createFromFormat('Y-m-d H:i:s', $c['data_consulta']);

                        if ($dt) {
                            $dataAtual = $dt->format('Y-m-d\TH:i');
                        }
                    }
                    ?>

                    <div class="card-consulta <?= $pendente ? 'nova' : '' ?>">

                        <h3><?= htmlspecialchars($c['nome_animal']) ?></h3>

                        <p class="tutor">
                            Tutor: <?= htmlspecialchars($c['tutor']) ?>
                        </p>

                        <div class="info-linha">
                            <span>Sintomas:</span>
                            <strong><?= htmlspecialchars($c['descricao_sintomas']) ?></strong>
                        </div>

                        <div class="info-linha">
                            <span>Especialidade:</span>
                            <strong><?= htmlspecialchars($c['nome_especialidade'] ?? 'A definir') ?></strong>
                        </div>

                        <div class="info-linha">
                            <span>Data:</span>
                            <strong>
                                <?php if (!empty($c['data_consulta'])): ?>
                                    <?php
                                    $dtVis = DateTime::createFromFormat('Y-m-d H:i:s', $c['data_consulta']);
                                    echo $dtVis ? $dtVis->format('d/m/Y H:i') : htmlspecialchars($c['data_consulta']);
                                    ?>
                                <?php else: ?>
                                    A definir
                                <?php endif; ?>
                            </strong>
                        </div>

                        <div class="info-linha">
                            <span>Status:</span>

                            <span class="badge <?= $pendente ? 'badge-pendente' : 'badge-atribuida' ?>">
                                <?= htmlspecialchars($c['STATUS']) ?>
                            </span>
                        </div>

                        <form method="POST" class="form-edicao">

                            <input type="hidden"
                                   name="atualizar_id"
                                   value="<?= (int) $c['id_consulta'] ?>">

                            <h4>Atualizar atendimento</h4>

                            <div class="campo">
                                <label>Data e horário agendados</label>

                                <input type="text" value="<?php
                                    if (!empty($c['data_consulta'])) {
                                        $dt = new DateTime($c['data_consulta']);
                                        echo htmlspecialchars($dt->format('d/m/Y H:i'));
                                    } else {
                                        echo 'Não definido';
                                    }
                                ?>" disabled>
                            </div>

                            <div class="campo">
                                <label>Especialidade</label>

                                <input type="text"
                                       value="<?= htmlspecialchars($c['nome_especialidade'] ?? 'Não definida') ?>"
                                       disabled>
                            </div>

                            <div class="campo">
                                <label>Valor da consulta</label>

                                <input type="text" value="<?php
                                    echo $c['valor_total'] !== null
                                        ? 'R$ ' . number_format((float) $c['valor_total'], 2, ',', '.')
                                        : 'Não definido';
                                ?>" disabled>
                            </div>

                            <div class="campo">
                                <label for="status_<?= (int) $c['id_consulta'] ?>">
                                    Status da consulta *
                                </label>

                                <select name="status"
                                        id="status_<?= (int) $c['id_consulta'] ?>"
                                        required>

                                    <?php foreach (['AGENDADA', 'CONFIRMADA', 'CANCELADA', 'ATENDIDO'] as $st): ?>

                                        <option value="<?= $st ?>"
                                            <?= $c['STATUS'] === $st ? 'selected' : '' ?>>
                                            <?= $st ?>
                                        </option>

                                    <?php endforeach; ?>

                                </select>
                            </div>

                            <button type="submit">Salvar status</button>

                        </form>

                    </div>

                <?php endforeach; ?>

            </div>

        <?php endif; ?>

    </main>

    <footer>
        © 2026 Pet Health — Cuidando de quem faz parte da sua família.
    </footer>

</body>
</html>
