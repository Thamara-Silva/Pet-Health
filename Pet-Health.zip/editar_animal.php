<?php
session_start();

// Proteção
if (
    !isset($_SESSION['id_usuario']) ||
    ($_SESSION['status'] ?? '') !== 'CLIENTE'
) {
    header('Location: home.php');
    exit;
}

require 'conexao.php';

$id_usuario = (int) $_SESSION['id_usuario'];
$idAnimal   = (int) ($_GET['id_animal'] ?? 0);

$mensagem = '';
$tipoMensagem = '';

// ============================================================
// 1) Busca o animal garantindo que pertence ao cliente
// ============================================================
$stmt = $pdo->prepare("
    SELECT id_animal, nome_animal, especie_animal, raca_animal,
           cor_animal, sexo_animal, data_nascimento_animal
    FROM ANIMAIS
    WHERE id_animal = ? AND id_usuario_fk = ?
");
$stmt->execute([$idAnimal, $id_usuario]);
$animal = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$animal) {
    header('Location: meus_animais.php');
    exit;
}

// ============================================================
// 2) Processa o POST (UPDATE)
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $nome       = trim($_POST['nome_animal'] ?? '');
    $especie    = trim($_POST['especie_animal'] ?? '');
    $raca       = trim($_POST['raca_animal'] ?? '');
    $cor        = trim($_POST['cor_animal'] ?? '');
    $sexo       = $_POST['sexo_animal'] ?? '';
    $nascimento = $_POST['data_nascimento_animal'] ?? '';

    if (
        $nome === '' || $raca === '' || $cor === '' ||
        $sexo === '' || $nascimento === ''
    ) {
        $mensagem = 'Preencha todos os campos obrigatórios.';
        $tipoMensagem = 'erro';
    } else {
        try {
            $stmtUp = $pdo->prepare("
                UPDATE ANIMAIS
                SET nome_animal            = ?,
                    especie_animal         = ?,
                    raca_animal            = ?,
                    cor_animal             = ?,
                    sexo_animal            = ?,
                    data_nascimento_animal = ?
                WHERE id_animal = ? AND id_usuario_fk = ?
            ");

            $stmtUp->execute([
                $nome, $especie, $raca, $cor, $sexo, $nascimento,
                $idAnimal, $id_usuario,
            ]);

            $mensagem = 'Animal atualizado com sucesso!';
            $tipoMensagem = 'sucesso';

            // Atualiza os dados na tela
            $animal['nome_animal']            = $nome;
            $animal['especie_animal']         = $especie;
            $animal['raca_animal']            = $raca;
            $animal['cor_animal']             = $cor;
            $animal['sexo_animal']            = $sexo;
            $animal['data_nascimento_animal'] = $nascimento;

        } catch (PDOException $e) {
            error_log($e->getMessage());
            $mensagem = 'Erro ao atualizar. Tente novamente.';
            $tipoMensagem = 'erro';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Animal | Pet Health</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Coiny&display=swap" rel="stylesheet">

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: Arial, sans-serif; }

        body {
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 30px 15px;
            background:
                linear-gradient(rgba(142, 107, 190, 0.82), rgba(185, 154, 222, 0.82)),
                url('./imgs/fundo.png');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
        }

        .container {
            width: 100%;
            max-width: 550px;
            background: #ffffff;
            border-radius: 24px;
            padding: 40px;
            box-shadow: 0 15px 40px rgba(65, 40, 85, 0.25);
        }

        .container h1 {
            font-family: "Coiny", system-ui;
            color: #594176;
            font-size: 30px;
            font-weight: normal;
            text-align: center;
            margin-bottom: 8px;
        }

        .subtitulo {
            text-align: center;
            color: #91859d;
            font-size: 14px;
            margin-bottom: 24px;
        }

        .mensagem {
            text-align: center;
            font-size: 14px;
            font-weight: bold;
            padding: 12px;
            border-radius: 11px;
            margin-bottom: 20px;
        }
        .mensagem.erro    { color: #a03535; background: #fde8e8; border: 1px solid #f5b5b5; }
        .mensagem.sucesso { color: #2c6e3a; background: #e6f7eb; border: 1px solid #b7e3c2; }

        .input-box { width: 100%; margin-bottom: 18px; }

        .input-box label {
            display: block;
            color: #594176;
            font-size: 14px;
            font-weight: bold;
            margin-bottom: 7px;
        }

        .input-box input,
        .input-box select {
            width: 100%;
            height: 48px;
            padding: 0 15px;
            border: 1px solid #e5dced;
            border-radius: 11px;
            outline: none;
            background: #fdfbff;
            color: #49385d;
            font-size: 14px;
            transition: 0.2s;
        }

        .input-box input:focus,
        .input-box select:focus {
            border-color: #9674c4;
            background: white;
            box-shadow: 0 0 0 3px rgba(150, 116, 196, 0.15);
        }

        .linha-dupla {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }

        button {
            width: 100%;
            height: 50px;
            border: none;
            border-radius: 12px;
            background: linear-gradient(90deg, #ef713f, #f28b62);
            color: white;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            margin-top: 10px;
            transition: 0.2s;
            box-shadow: 0 5px 12px rgba(239, 113, 63, 0.2);
        }

        button:hover {
            transform: translateY(-2px);
            background: linear-gradient(90deg, #dc5f2f, #e97950);
        }

        .voltar {
            display: block;
            text-align: center;
            margin-top: 16px;
            padding: 12px;
            border-radius: 11px;
            text-decoration: none;
            color: #7655a3;
            background-color: #f7f1ff;
            font-size: 14px;
            font-weight: bold;
            transition: 0.2s;
        }

        .voltar:hover { background-color: #e9dcfa; color: #594176; }

        @media (max-width: 550px) {
            .container { padding: 28px 22px; }
            .linha-dupla { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>

    <main class="container">
        <form method="POST">
            <h1>✏️ Editar Pet</h1>
            <p class="subtitulo">Atualize as informações do seu animal</p>

            <?php if ($mensagem !== ''): ?>
                <div class="mensagem <?= htmlspecialchars($tipoMensagem) ?>">
                    <?= htmlspecialchars($mensagem) ?>
                </div>
            <?php endif; ?>

            <div class="input-box">
                <label for="nome_animal">Nome do Animal *</label>
                <input type="text" id="nome_animal" name="nome_animal"
                    value="<?= htmlspecialchars($animal['nome_animal']) ?>" required>
            </div>

            <div class="linha-dupla">
                <div class="input-box">
                    <label for="especie_animal">Espécie</label>
                    <input type="text" id="especie_animal" name="especie_animal"
                        value="<?= htmlspecialchars($animal['especie_animal'] ?? '') ?>">
                </div>
                <div class="input-box">
                    <label for="raca_animal">Raça *</label>
                    <input type="text" id="raca_animal" name="raca_animal"
                        value="<?= htmlspecialchars($animal['raca_animal']) ?>" required>
                </div>
            </div>

            <div class="linha-dupla">
                <div class="input-box">
                    <label for="cor_animal">Cor *</label>
                    <input type="text" id="cor_animal" name="cor_animal"
                        value="<?= htmlspecialchars($animal['cor_animal']) ?>" required>
                </div>
                <div class="input-box">
                    <label for="sexo_animal">Sexo *</label>
                    <select id="sexo_animal" name="sexo_animal" required>
                        <option value="">Selecione...</option>
                        <option value="Macho" <?= $animal['sexo_animal'] === 'Macho' ? 'selected' : '' ?>>Macho</option>
                        <option value="Fêmea" <?= $animal['sexo_animal'] === 'Fêmea' ? 'selected' : '' ?>>Fêmea</option>
                    </select>
                </div>
            </div>

            <div class="input-box">
                <label for="data_nascimento_animal">Data de Nascimento *</label>
                <input type="date" id="data_nascimento_animal" name="data_nascimento_animal"
                    value="<?= htmlspecialchars($animal['data_nascimento_animal']) ?>" required>
            </div>

            <button type="submit">Salvar alterações</button>
            <a href="meus_animais.php" class="voltar">← Voltar para Meus Animais</a>
        </form>
    </main>

</body>
</html>