
<?php
session_start();

// Proteção: apenas clientes logados podem acessar
if (
    !isset($_SESSION['id_usuario']) ||
    !isset($_SESSION['status']) ||
    $_SESSION['status'] !== 'CLIENTE'
) {
    header('Location: home.php');
    exit;
}

require 'conexao.php';

$id_usuario = $_SESSION['id_usuario'];
$nome = htmlspecialchars($_SESSION['nome_usuario'] ?? 'Cliente', ENT_QUOTES, 'UTF-8');

$mensagem = '';
$tipoMensagem = '';

// Exclusão do animal
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['excluir_id'])) {

    $idExcluir = (int) $_POST['excluir_id'];

    $stmtDel = $pdo->prepare("
        DELETE FROM ANIMAIS
        WHERE id_animal = ? AND id_usuario_fk = ?
    ");
    $stmtDel->execute([$idExcluir, $id_usuario]);

    if ($stmtDel->rowCount() > 0) {
        $mensagem = 'Animal excluído com sucesso.';
        $tipoMensagem = 'sucesso';
    } else {
        $mensagem = 'Animal não encontrado ou não pertence à sua conta.';
        $tipoMensagem = 'erro';
    }
}

// Busca os animais do cliente
try {
    $stmt = $pdo->prepare("
        SELECT id_animal, nome_animal, especie_animal, raca_animal,
               cor_animal, sexo_animal, data_nascimento_animal
        FROM ANIMAIS
        WHERE id_usuario_fk = ?
        ORDER BY nome_animal ASC
    ");
    $stmt->execute([$id_usuario]);
    $animais = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    error_log($e->getMessage());
    $erro = true;
    $mensagem = 'Erro ao carregar animais.';
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Meus Animais | Pet Health</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link href="https://fonts.googleapis.com/css2?family=Coiny&family=Nunito:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Nunito', sans-serif;
        }

        body {
            min-height: 100vh;
            background: linear-gradient(135deg, #f7f1ff, #e9dcfa, #fff4ed);
            color: #665b70;
        }

        header {
            background: #ffffff;
            padding: 18px 8%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 15px;
            flex-wrap: wrap;
            box-shadow: 0 4px 20px rgba(118, 85, 163, 0.08);
        }

        .texto-logo {
            font-family: 'Coiny', system-ui;
            font-size: 30px;
            color: #7655a3;
        }

        .texto-logo span {
            font-family: 'Coiny', system-ui;
            color: #ef713f;
        }

        .sair {
            background: #ef713f;
            color: white;
            padding: 11px 22px;
            text-decoration: none;
            border-radius: 11px;
            font-weight: 800;
            font-size: 14px;
            transition: 0.2s;
            box-shadow: 0 4px 10px rgba(239, 113, 63, 0.2);
        }

        .sair:hover {
            background: #dc6031;
            transform: translateY(-2px);
        }

        main {
            width: 90%;
            max-width: 1100px;
            margin: 40px auto;
        }

        .topo-pagina {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 28px;
            flex-wrap: wrap;
            gap: 15px;
        }

        .topo-pagina h2 {
            font-family: 'Coiny', system-ui;
            font-size: 32px;
            color: #594176;
            font-weight: normal;
        }

        .btn-add {
            background: #ef713f;
            color: white;
            padding: 12px 20px;
            text-decoration: none;
            border-radius: 11px;
            font-weight: 800;
            font-size: 14px;
            transition: 0.2s;
            box-shadow: 0 4px 10px rgba(239, 113, 63, 0.2);
        }

        .btn-add:hover {
            background: #dc6031;
            transform: translateY(-2px);
        }

        .mensagem {
            padding: 14px 18px;
            border-radius: 12px;
            margin-bottom: 22px;
            font-weight: 800;
            text-align: center;
        }

        .mensagem.sucesso {
            background: #e6f7eb;
            color: #2c6e3a;
            border: 1px solid #b7e3c2;
        }

        .mensagem.erro {
            background: #fde8e8;
            color: #a03535;
            border: 1px solid #f5b5b5;
        }

        .grid-animais {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 22px;
        }

        .card-animal {
            background: #ffffff;
            border-radius: 20px;
            padding: 25px;
            box-shadow: 0 8px 25px rgba(118, 85, 163, 0.08);
            border-top: 5px solid #ef713f;
            transition: 0.3s ease;
            display: flex;
            flex-direction: column;
        }

        .card-animal:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 30px rgba(118, 85, 163, 0.15);
        }

        .card-animal h3 {
            font-family: 'Coiny', system-ui;
            font-size: 24px;
            color: #594176;
            margin-bottom: 15px;
            font-weight: normal;
        }

        .info-linha {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 12px;
            padding: 9px 0;
            border-bottom: 1px solid #f0eaf5;
            font-size: 14px;
            color: #776985;
        }

        .info-linha:last-of-type {
            border-bottom: none;
        }

        .info-linha strong {
            color: #594176;
            text-align: right;
            overflow-wrap: anywhere;
        }

        .acoes-card {
            display: flex;
            gap: 10px;
            margin-top: 18px;
            padding-top: 15px;
            border-top: 1px dashed #e5dced;
        }

        .acoes-card form {
            flex: 1;
            margin: 0;
        }

        .btn-acao {
            width: 100%;
            padding: 11px;
            border: none;
            border-radius: 10px;
            font-size: 14px;
            font-weight: 800;
            cursor: pointer;
            transition: 0.2s;
            text-align: center;
            text-decoration: none;
            display: inline-block;
        }

        .btn-editar {
            background: #f0eaf5;
            color: #594176;
        }

        .btn-editar:hover {
            background: #e3d8ee;
        }

        .btn-excluir {
            background: #fde8e8;
            color: #a03535;
        }

        .btn-excluir:hover {
            background: #f8d4d4;
        }

        .mensagem-vazia {
            background: #ffffff;
            padding: 40px;
            border-radius: 20px;
            text-align: center;
            box-shadow: 0 8px 25px rgba(118, 85, 163, 0.08);
            color: #776985;
        }

        .mensagem-vazia h3 {
            font-family: 'Coiny', system-ui;
            color: #594176;
            margin-bottom: 10px;
            font-weight: normal;
            font-size: 23px;
        }

        .btn-voltar {
            display: inline-block;
            margin-top: 25px;
            padding: 12px 20px;
            background: #ffffff;
            color: #7655a3;
            text-decoration: none;
            border-radius: 11px;
            font-weight: 800;
            transition: 0.2s;
            box-shadow: 0 4px 12px rgba(118, 85, 163, 0.08);
        }

        .btn-voltar:hover {
            background: #f0eaf8;
            transform: translateY(-2px);
        }

        footer {
            text-align: center;
            padding: 25px 15px;
            color: #91859d;
            font-size: 13px;
        }

        @media (max-width: 768px) {
            header {
                flex-direction: column;
                text-align: center;
                padding: 20px;
            }

            .topo-pagina {
                flex-direction: column;
                text-align: center;
            }

            .topo-pagina h2 {
                font-size: 28px;
            }
        }

        @media (max-width: 400px) {
            .acoes-card {
                flex-direction: column;
            }

            .acoes-card form {
                width: 100%;
            }

            .info-linha {
                font-size: 13px;
            }
        }
    </style>
</head>

<body>

    <header>
        <div class="texto-logo">Pet <span>Health</span></div>

        <a class="sair" href="logout.php"
           onclick="return confirm('Tem certeza de que deseja sair da sua conta?');">
            Sair da conta
        </a>
    </header>

    <main>

        <div class="topo-pagina">
            <h2>Meus Animais</h2>

            <a href="novo_animal.php" class="btn-add">
                + Cadastrar novo pet
            </a>
        </div>

        <?php if ($mensagem !== ''): ?>
            <div class="mensagem <?= htmlspecialchars($tipoMensagem) ?>">
                <?= htmlspecialchars($mensagem) ?>
            </div>
        <?php endif; ?>

        <?php if (isset($erro)): ?>

            <div class="mensagem-vazia">
                <h3>Erro ao carregar</h3>
                <p>Tente novamente mais tarde.</p>
            </div>

        <?php elseif (count($animais) > 0): ?>

            <div class="grid-animais">

                <?php foreach ($animais as $animal): ?>

                    <div class="card-animal">

                        <h3><?= htmlspecialchars($animal['nome_animal']) ?></h3>

                        <div class="info-linha">
                            <span>Espécie:</span>
                            <strong><?= htmlspecialchars($animal['especie_animal'] ?? 'Não informada') ?></strong>
                        </div>

                        <div class="info-linha">
                            <span>Raça:</span>
                            <strong><?= htmlspecialchars($animal['raca_animal']) ?></strong>
                        </div>

                        <div class="info-linha">
                            <span>Cor:</span>
                            <strong><?= htmlspecialchars($animal['cor_animal']) ?></strong>
                        </div>

                        <div class="info-linha">
                            <span>Sexo:</span>
                            <strong><?= htmlspecialchars($animal['sexo_animal']) ?></strong>
                        </div>

                        <div class="info-linha">
                            <span>Nascimento:</span>
                            <strong>
                                <?php
                                if (!empty($animal['data_nascimento_animal'])) {
                                    $data = DateTime::createFromFormat('Y-m-d', $animal['data_nascimento_animal']);
                                    echo $data ? $data->format('d/m/Y') : htmlspecialchars($animal['data_nascimento_animal']);
                                } else {
                                    echo 'Não informada';
                                }
                                ?>
                            </strong>
                        </div>

                        <div class="acoes-card">

                            <a class="btn-acao btn-editar"
                               href="editar_animal.php?id_animal=<?= (int) $animal['id_animal'] ?>">
                                Alterar
                            </a>

                            <form method="POST"
                                  onsubmit="return confirm('Tem certeza que deseja excluir este animal? Esta ação não pode ser desfeita.');">

                                <input type="hidden"
                                       name="excluir_id"
                                       value="<?= (int) $animal['id_animal'] ?>">

                                <button type="submit" class="btn-acao btn-excluir">
                                    Excluir
                                </button>

                            </form>

                        </div>

                    </div>

                <?php endforeach; ?>

            </div>

        <?php else: ?>

            <div class="mensagem-vazia">
                <h3>Nenhum animal cadastrado</h3>
                <p>
                    Você ainda não cadastrou nenhum pet.
                    Clique no botão acima para adicionar seu primeiro amigo!
                </p>
            </div>

        <?php endif; ?>

        <div style="text-align: center;">
            <a href="cliente.php" class="btn-voltar">
                ← Voltar para a área do cliente
            </a>
        </div>

    </main>

    <footer>
        © 2026 Pet Health — Cuidando de quem faz parte da sua família.
    </footer>

</body>
</html>
