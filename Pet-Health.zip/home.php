<?php
session_start();

?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Coiny&display=swap" rel="stylesheet">
    <title>Pet Health | Sua saúde animal</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        .logo,
        .apresentacao h1,
        .card-login h2 {
            font-family: "Coiny", system-ui;
        }

        body {
            min-height: 100vh;
            background: linear-gradient(135deg,
                    #f7f1ff,
                    #e9dcfa,
                    #fff4ed);
            color: #413055ff;
        }

        .pagina {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 60px;
            padding: 60px 17%;
        }

        /* LADO ESQUERDO */

        .apresentacao {
            flex: 1;
            max-width: 500px;
        }

        .logo {
            font-size: 30px;
            font-weight: bold;
            color: #7655a3;
            margin-bottom: 65px;
        }

        .logo span {
            color: #ef713f;
        }

        .etiqueta {
            display: inline-block;
            background: #ffffffb8;
            color: #7655a3;
            padding: 10px 16px;
            border-radius: 30px;
            margin-bottom: 24px;
            font-size: 15px;
        }

        .apresentacao h1 {
            font-size: clamp(36px, 4vw, 54px);
            line-height: 1.15;
            margin-bottom: 22px;
            color: #594176;
        }

        .apresentacao h1 span {
            color: #ef713f;
        }

        .apresentacao p {
            font-size: 17px;
            line-height: 1.8;
            color: #776985;
            max-width: 450px;
        }

        .mensagem {
            margin-top: 35px;
            display: flex;
            align-items: center;
            gap: 12px;
            color: #7655a3;
            font-size: 14px;
        }

        .patinha {
            font-size: 30px;
        }

        /* LADO DIREITO: LOGIN */

        .area-login {
            width: 100%;
            max-width: 480px;
            flex-shrink: 0;
        }

        .card-login {
            background: #ffffff;
            padding: 42px 36px;
            border-radius: 24px;
            box-shadow: 0 15px 50px #7655a31a;
        }

        .card-login h2 {
            font-size: 28px;
            color: #594176;
            margin-bottom: 10px;
        }

        .subtitulo {
            font-size: 14px;
            line-height: 1.6;
            color: #91859d;
            margin-bottom: 30px;
        }

        .campo {
            margin-bottom: 20px;
        }

        .campo label {
            display: block;
            margin-bottom: 9px;
            font-size: 14px;
            font-weight: bold;
            color: #594176;
        }

        .campo input {
            width: 100%;
            padding: 14px 15px;
            border: 1px solid #e5dced;
            border-radius: 11px;
            outline: none;
            font-size: 14px;
            color: #49385d;
            background: #fdfbff;
            transition: 0.2s;
        }

        .campo input:focus {
            border-color: #9674c4;
            box-shadow: 0 0 0 3px #9674c422;
        }

        .botao {
            width: 100%;
            border: none;
            border-radius: 11px;
            padding: 15px;
            background: #ef713f;
            color: white;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: 0.2s;
        }

        .botao:hover {
            background: #dc6031;
            transform: translateY(-2px);
        }

        .erro {
            color: red;
            font-size: 15px;
            margin-bottom: 10px;
        }

        .mensagem-temporaria {
            animation: desaparecer 0.5s ease 2s forwards;
        }

        @keyframes desaparecer {
            from {
                opacity: 1;
            }

            to {
                opacity: 0;
                visibility: hidden;
            }
        }

        .rodape-login {
            text-align: center;
            margin-top: 25px;
            font-size: 13px;
            color: #91859d;
        }

        .rodape-login a {
            color: #7655a3;
            font-weight: bold;
            text-decoration: none;
        }

        .rodape-login a:hover {
            text-decoration: underline;
        }

        .rodape-pagina {
            text-align: center;
            padding: 0 20px 25px;
            font-size: 12px;
            color: #998ba8;
        }

        /* ADAPTAÇÃO PARA CELULARES */

        @media (max-width: 900px) {
            .pagina {
                flex-direction: column;
                justify-content: center;
                gap: 40px;
                padding: 35px 20px;
            }

            .apresentacao {
                text-align: center;
            }

            .logo {
                margin-bottom: 35px;
            }

            .apresentacao p {
                margin: 0 auto;
            }

            .mensagem {
                justify-content: center;
            }

            .area-login {
                max-width: 450px;
            }
        }

        @media (max-width: 480px) {
            .card-login {
                padding: 32px 24px;
            }

            .apresentacao h1 {
                font-size: 35px;
            }
        }
    </style>
</head>

<body>

    <main class="pagina">

        <section class="apresentacao">

            <div class="logo">
                Pet <span class="logo">Health</span>
            </div>

            <div class="etiqueta">
                ♡ Cuidado que vem do coração
            </div>

            <h1>
                Seu pet merece
                <span>o melhor cuidado.</span>
            </h1>

            <p>
                Acompanhe a saúde do seu melhor amigo em um só lugar.
                Organize consultas, consulte informações e tenha
                mais praticidade no cuidado com quem você ama.
            </p>


        </section>

        <section class="area-login">

            <div class="card-login">

                <?php if (isset($_GET['erro'])): ?>
                    <?php if ($_GET['erro'] == 1): ?>
                        <p class="erro mensagem-temporaria">Usuário não encontrado.</p>
                    <?php elseif ($_GET['erro'] == 2): ?>
                        <p class="erro mensagem-temporaria">Senha incorreta. Tente novamente.</p>
                    <?php endif; ?>
                <?php endif; ?>

                <h2>Bem-vindo(a)!</h2>

                <p class="subtitulo">
                    Entre na sua conta para acessar o Pet Health.
                </p>

                <form action="login.php" method="POST">

                    <div class="campo">
                        <label for="email_usuario">E-mail</label>

                        <input type="email" id="email_usuario" name="email_usuario" placeholder="Digite seu e-mail"
                            autocomplete="email" required>
                    </div>

                    <div class="campo">
                        <label for="senha_usuario">Senha</label>

                        <input type="password" id="senha_usuario" name="senha_usuario" placeholder="Digite sua senha"
                            autocomplete="current-password" required>
                    </div>

                    <button type="submit" class="botao">
                        Entrar na conta
                    </button>

                </form>

                <div class="rodape-login">
                    Ainda não tem uma conta?
                    <a href="cadastro_usuario.php">Cadastre-se</a>
                </div>

            </div>

        </section>

    </main>

    <footer class="rodape-pagina">
        © 2026 Pet Health — Cuidando de quem faz parte da sua família.
    </footer>

</body>

</html>