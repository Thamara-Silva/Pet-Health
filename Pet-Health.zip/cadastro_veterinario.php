
<?php

session_start();

if (
    !isset($_SESSION['id_usuario']) ||
    ($_SESSION['status'] ?? '') !== 'ADMINISTRADOR'
) {
    header('Location: home.php');
    exit;
}

require_once 'conexao.php';

$mensagem = '';
$tipoMensagem = '';

$especialidades = $pdo->query("
    SELECT id_especialidade, nome_especialidade
    FROM ESPECIALIDADES
    ORDER BY nome_especialidade
")->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // 1. Coleta dos dados pessoais e profissionais.
    $nome = trim($_POST['nome_veterinario'] ?? '');
    $email = trim($_POST['email_usuario'] ?? '');
    $telefone = trim($_POST['telefone_usuario'] ?? '');
    $senha = $_POST['senha_usuario'] ?? '';
    $confirmarSenha = $_POST['confSenha'] ?? '';

    $crm = trim($_POST['crm_veterinario'] ?? '');
    $crmUF = strtoupper(trim($_POST['crm_uf_veterinario'] ?? ''));

    $especialidade = $_POST['id_especialidade_fk'] ?? '';

    // 2. Coleta do endereço.
    $logradouro = trim($_POST['logradouro'] ?? '');
    $numero = trim($_POST['numero'] ?? '');
    $complemento = trim($_POST['complemento'] ?? '');
    $bairro = trim($_POST['bairro'] ?? '');
    $cidade = trim($_POST['cidade'] ?? '');
    $uf = strtoupper(trim($_POST['uf'] ?? ''));
    $cep = preg_replace('/\D/', '', $_POST['cep'] ?? '');

    // 3. Validações.
    if (
        $nome === '' ||
        !filter_var($email, FILTER_VALIDATE_EMAIL) ||
        $telefone === '' ||
        $crm === '' ||
        !preg_match('/^[A-Z]{2}$/', $crmUF) ||
        $logradouro === '' ||
        $numero === '' ||
        $bairro === '' ||
        $cidade === '' ||
        !preg_match('/^[A-Z]{2}$/', $uf) ||
        !preg_match('/^\d{8}$/', $cep) ||
        !ctype_digit((string)$especialidade)
    ) {
        $mensagem = 'Confira os dados preenchidos. Há campos inválidos.';
        $tipoMensagem = 'erro';

    } elseif (strlen($senha) < 8) {

        $mensagem = 'A senha deve ter pelo menos 8 caracteres.';
        $tipoMensagem = 'erro';

    } elseif ($senha !== $confirmarSenha) {

        $mensagem = 'As senhas não coincidem.';
        $tipoMensagem = 'erro';

    } else {

        try {

            $pdo->beginTransaction();

            // 4. Confere se o e-mail já está cadastrado.
            $stmtEmail = $pdo->prepare("
                SELECT id_usuario
                FROM USUARIOS
                WHERE email_usuario = ?
            ");

            $stmtEmail->execute([$email]);

            if ($stmtEmail->fetch()) {
                throw new DomainException(
                    'Este e-mail já está cadastrado no sistema.'
                );
            }

            // 5. Confere se a especialidade existe.
            $stmtEspecialidade = $pdo->prepare("
                SELECT id_especialidade
                FROM ESPECIALIDADES
                WHERE id_especialidade = ?
            ");

            $stmtEspecialidade->execute([(int)$especialidade]);

            if (!$stmtEspecialidade->fetch()) {
                throw new DomainException(
                    'Selecione uma especialidade válida.'
                );
            }

            // 6. Cadastra o endereço.
            $stmtEndereco = $pdo->prepare("
                INSERT INTO ENDERECOS (
                    logradouro, numero, complemento,
                    bairro, cidade, uf, cep
                )
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ");

            $stmtEndereco->execute([
                $logradouro,
                $numero,
                $complemento !== '' ? $complemento : null,
                $bairro,
                $cidade,
                $uf,
                $cep
            ]);

            $idEndereco = $pdo->lastInsertId();

            // 7. Cria a conta de acesso do veterinário.
            $hashSenha = password_hash($senha, PASSWORD_DEFAULT);

            $stmtUsuario = $pdo->prepare("
                INSERT INTO USUARIOS (
                    nome_usuario,
                    email_usuario,
                    senha_usuario,
                    STATUS,
                    telefone_usuario,
                    id_endereco_fk
                )
                VALUES (?, ?, ?, 'VETERINARIO', ?, ?)
            ");

            $stmtUsuario->execute([
                $nome,
                $email,
                $hashSenha,
                $telefone,
                $idEndereco
            ]);

            $idUsuario = $pdo->lastInsertId();

            // 8. Cadastra os dados profissionais.
            $stmtVeterinario = $pdo->prepare("
                INSERT INTO VETERINARIOS (
                    id_usuario_fk,
                    nome_veterinario,
                    email_usuario,
                    crm_veterinario,
                    crm_uf_veterinario,
                    telefone_usuario,
                    id_especialidade_fk,
                    id_endereco_fk
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ");

            $stmtVeterinario->execute([
                $idUsuario,
                $nome,
                $email,
                $crm,
                $crmUF,
                $telefone,
                (int)$especialidade,
                $idEndereco
            ]);

            // 9. Confirma todas as inserções.
            $pdo->commit();

            $mensagem = 'Veterinário cadastrado com sucesso!';
            $tipoMensagem = 'sucesso';

        } catch (DomainException $e) {

            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            $mensagem = $e->getMessage();
            $tipoMensagem = 'erro';

        } catch (PDOException $e) {

            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            error_log($e->getMessage());

            $mensagem = 'Não foi possível concluir o cadastro. Confira os dados e tente novamente.';
            $tipoMensagem = 'erro';
        }
    }
}

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Cadastro de Veterinário | Pet Health</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Coiny&family=Nunito:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Nunito', sans-serif;
        }

        body {
            min-height: 100vh;
            padding: 35px 15px;
            display: flex;
            justify-content: center;
            align-items: center;

            background:
                linear-gradient(
                    rgba(118, 85, 163, 0.76),
                    rgba(185, 154, 222, 0.78)
                ),
                url('./imgs/fundo.png');

            background-size: cover;
            background-position: center;
            background-attachment: fixed;
        }

        .container-cadastro {
            width: 100%;
            max-width: 650px;
            background: rgba(255, 255, 255, 0.97);
            padding: 38px 42px;
            border-radius: 25px;
            box-shadow: 0 15px 45px rgba(65, 40, 85, 0.23);
            border: 1px solid rgba(255, 255, 255, 0.7);
        }

        /* Identidade da marca */

        .logo {
            text-align: center;
            font-family: 'Coiny', cursive;
            font-size: 34px;
            color: #7655a3;
            margin-bottom: 5px;
        }

        .logo span {
            font-family: 'Coiny', cursive;
            color: #ef713f;
        }

        .subtitulo {
            text-align: center;
            color: #91859d;
            font-size: 14px;
            margin-bottom: 25px;
        }

        /* Mensagens */

        .mensagem {
            text-align: center;
            font-size: 14px;
            font-weight: 800;
            padding: 13px;
            border-radius: 12px;
            margin-bottom: 20px;
        }

        .mensagem.erro {
            color: #a03535;
            background: #fde8e8;
            border: 1px solid #f5b5b5;
        }

        .mensagem.sucesso {
            color: #2c6e3a;
            background: #e6f7eb;
            border: 1px solid #b7e3c2;
        }

        /* Seções */

        .secao-titulo {
            color: #7655a3;
            font-size: 16px;
            font-weight: 800;
            margin: 25px 0 16px;
            padding-bottom: 9px;
            border-bottom: 2px solid #eee6f5;
        }

        /* Campos */

        .campo {
            width: 100%;
            margin-bottom: 17px;
        }

        .linha-dupla {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }

        label {
            display: block;
            color: #594176;
            font-size: 14px;
            font-weight: 800;
            margin-bottom: 7px;
        }

        input[type="text"],
        input[type="email"],
        input[type="tel"],
        input[type="password"],
        select {
            width: 100%;
            height: 48px;
            padding: 0 14px;
            border: 2px solid #e6dcef;
            border-radius: 11px;
            outline: none;
            background: #fcfaff;
            color: #493d52;
            font-size: 14px;
            transition: 0.2s;
        }

        input:focus,
        select:focus {
            border-color: #8e6bbe;
            background: white;
            box-shadow: 0 0 0 3px rgba(142, 107, 190, 0.12);
        }

        input::placeholder {
            color: #aa9bb3;
        }

        .uf {
            text-transform: uppercase;
        }

        /* Botões */

        .botao-cadastrar {
            width: 100%;
            height: 51px;
            border: none;
            border-radius: 12px;
            background: linear-gradient(90deg, #ef713f, #f28b62);
            color: white;
            font-size: 16px;
            font-weight: 800;
            cursor: pointer;
            margin-top: 8px;
            box-shadow: 0 5px 12px rgba(239, 113, 63, 0.2);
            transition: 0.2s;
        }

        .botao-cadastrar:hover {
            background: linear-gradient(90deg, #dc5f2f, #e97950);
            transform: translateY(-2px);
        }

        .botao-limpar {
            width: 100%;
            height: 46px;
            border: none;
            border-radius: 12px;
            background: #eee6f5;
            color: #7655a3;
            font-size: 15px;
            font-weight: 800;
            cursor: pointer;
            margin-top: 12px;
            transition: 0.2s;
        }

        .botao-limpar:hover {
            background: #dfd2eb;
        }

        .link-voltar {
            display: block;
            text-align: center;
            margin-top: 17px;
            padding: 12px;
            border-radius: 11px;
            text-decoration: none;
            color: #7655a3;
            background: #f3edfa;
            font-size: 14px;
            font-weight: 800;
            transition: 0.2s;
        }

        .link-voltar:hover {
            background: #e6d9f3;
        }

        /* Responsividade */

        @media (max-width: 550px) {
            .container-cadastro {
                padding: 28px 22px;
                border-radius: 20px;
            }

            .logo {
                font-size: 29px;
            }

            .linha-dupla {
                grid-template-columns: 1fr;
                gap: 0;
            }
        }
    </style>
</head>

<body>

    <main class="container-cadastro">

        <h1 class="logo">Pet <span>Health</span></h1>

        <p class="subtitulo">
            Cadastro profissional da equipe veterinária
        </p>

        <?php if ($mensagem !== ''): ?>

            <div class="mensagem <?= htmlspecialchars($tipoMensagem, ENT_QUOTES, 'UTF-8') ?>">
                <?= htmlspecialchars($mensagem, ENT_QUOTES, 'UTF-8') ?>
            </div>

        <?php endif; ?>

        <form action="<?= htmlspecialchars($_SERVER['PHP_SELF'], ENT_QUOTES, 'UTF-8') ?>" method="POST">

            <h2 class="secao-titulo">👤 Dados pessoais</h2>

            <div class="campo">
                <label for="nome_veterinario">Nome completo:</label>
                <input
                    type="text"
                    id="nome_veterinario"
                    name="nome_veterinario"
                    maxlength="100"
                    required
                >
            </div>

            <div class="campo">
                <label for="email_usuario">E-mail de acesso:</label>
                <input
                    type="email"
                    id="email_usuario"
                    name="email_usuario"
                    maxlength="100"
                    required
                >
            </div>

            <div class="campo">
                <label for="telefone_usuario">Telefone:</label>
                <input
                    type="tel"
                    id="telefone_usuario"
                    name="telefone_usuario"
                    maxlength="20"
                    required
                >
            </div>

            <div class="linha-dupla">

                <div class="campo">
                    <label for="senha_usuario">Senha de acesso:</label>
                    <input
                        type="password"
                        id="senha_usuario"
                        name="senha_usuario"
                        minlength="8"
                        maxlength="60"
                        autocomplete="new-password"
                        required
                    >
                </div>

                <div class="campo">
                    <label for="confSenha">Confirmar senha:</label>
                    <input
                        type="password"
                        id="confSenha"
                        name="confSenha"
                        minlength="8"
                        maxlength="60"
                        autocomplete="new-password"
                        required
                    >
                </div>

            </div>

            <h2 class="secao-titulo">🩺 Dados profissionais</h2>

            <div class="linha-dupla">

                <div class="campo">
                    <label for="crm_veterinario">Número do CRMV:</label>
                    <input
                        type="text"
                        id="crm_veterinario"
                        name="crm_veterinario"
                        maxlength="20"
                        placeholder="12345"
                        required
                    >
                </div>

                <div class="campo">
                    <label for="crm_uf_veterinario">UF do CRMV:</label>
                    <input
                        type="text"
                        id="crm_uf_veterinario"
                        name="crm_uf_veterinario"
                        class="uf"
                        maxlength="2"
                        minlength="2"
                        placeholder="SP"
                        required
                    >
                </div>

            </div>

            <div class="campo">
                <label for="id_especialidade_fk">Especialidade:</label>

                <select
                    id="id_especialidade_fk"
                    name="id_especialidade_fk"
                    required
                >
                    <option value="">Selecione uma especialidade</option>

                    <?php foreach ($especialidades as $especialidadeItem): ?>

                        <option value="<?= (int)$especialidadeItem['id_especialidade'] ?>">
                            <?= htmlspecialchars(
                                $especialidadeItem['nome_especialidade'],
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?>
                        </option>

                    <?php endforeach; ?>

                </select>
            </div>

            <h2 class="secao-titulo">📍 Endereço</h2>

            <div class="campo">
                <label for="logradouro">Logradouro:</label>
                <input
                    type="text"
                    id="logradouro"
                    name="logradouro"
                    maxlength="100"
                    placeholder="Rua, Avenida, etc."
                    required
                >
            </div>

            <div class="linha-dupla">

                <div class="campo">
                    <label for="numero">Número:</label>
                    <input
                        type="text"
                        id="numero"
                        name="numero"
                        maxlength="10"
                        required
                    >
                </div>

                <div class="campo">
                    <label for="complemento">Complemento:</label>
                    <input
                        type="text"
                        id="complemento"
                        name="complemento"
                        maxlength="50"
                        placeholder="Apto, Bloco..."
                    >
                </div>

            </div>

            <div class="campo">
                <label for="bairro">Bairro:</label>
                <input
                    type="text"
                    id="bairro"
                    name="bairro"
                    maxlength="50"
                    required
                >
            </div>

            <div class="linha-dupla">

                <div class="campo">
                    <label for="cidade">Cidade:</label>
                    <input
                        type="text"
                        id="cidade"
                        name="cidade"
                        maxlength="50"
                        required
                    >
                </div>

                <div class="campo">
                    <label for="uf">UF:</label>
                    <input
                        type="text"
                        id="uf"
                        name="uf"
                        class="uf"
                        maxlength="2"
                        minlength="2"
                        placeholder="SP"
                        required
                    >
                </div>

            </div>

            <div class="campo">
                <label for="cep">CEP:</label>
                <input
                    type="text"
                    id="cep"
                    name="cep"
                    maxlength="9"
                    placeholder="Somente números"
                    required
                >
            </div>

            <button class="botao-cadastrar" type="submit">
                Cadastrar veterinário
            </button>

            <button class="botao-limpar" type="reset">
                Limpar formulário
            </button>

            <a class="link-voltar" href="admin.php">
                Voltar ao painel administrativo
            </a>

        </form>

    </main>

</body>
</html>
