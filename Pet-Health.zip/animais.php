
<?php

session_start();

// 1. Protege a página: somente administradores podem acessá-la.
if (
    !isset($_SESSION['id_usuario']) ||
    ($_SESSION['status'] ?? '') !== 'ADMINISTRADOR'
) {
    header('Location: home.php');
    exit;
}

// 2. Importa a conexão.
require_once 'conexao.php';

// 3. Busca os animais e seus respectivos tutores.
$erro = false;

try {
    $sql = "SELECT
                an.id_animal,
                an.nome_animal,
                an.especie_animal,
                an.raca_animal,
                an.cor_animal,
                an.sexo_animal,
                an.data_nascimento_animal,
                u.nome_usuario
            FROM ANIMAIS an
            LEFT JOIN USUARIOS u
                ON an.id_usuario_fk = u.id_usuario
            ORDER BY an.nome_animal ASC";

    $stmt = $pdo->query($sql);
    $animais = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    error_log($e->getMessage());
    $erro = true;
}

// 4. Protege os textos exibidos.
function limparTexto($texto)
{
    return htmlspecialchars(
        (string) ($texto ?? ''),
        ENT_QUOTES,
        'UTF-8'
    );
}

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Animais cadastrados | Pet Health</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Coiny&family=Nunito:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Nunito', sans-serif;
        }

        body {
            min-height: 100vh;
            background: linear-gradient(
                135deg,
                #f7f1ff,
                #e9dcfa,
                #fff4ed
            );
            color: #594176;
            padding: 35px 5%;
        }

        /* Cabeçalho */

        header {
            max-width: 1350px;
            margin: 0 auto 28px;
            background: rgba(255, 255, 255, 0.95);
            padding: 20px 28px;
            border-radius: 18px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
            box-shadow: 0 5px 20px rgba(89, 65, 118, 0.08);
        }

        .logo {
            font-family: 'Coiny', cursive;
            font-size: 26px;
            color: #7655a3;
        }

        .logo span {
            font-family: 'Coiny', cursive;
            color: #ef713f;
        }

  
        .voltar {
            background: #ef713f;
            color: white;
            padding: 11px 20px;
            text-decoration: none;
            border-radius: 11px;
            font-weight: 800;
            transition: 0.3s;
        }

        .voltar:hover {
            background: #dc6031;
            transform: translateY(-2px);
        }

        /* Conteúdo */

        main {
            max-width: 1350px;
            margin: auto;
        }

        .conteudo {
            background: rgba(255, 255, 255, 0.96);
            padding: 32px;
            border-radius: 22px;
            box-shadow: 0 8px 25px rgba(73, 61, 82, 0.09);
        }

        .titulo {
            font-family: 'Coiny', cursive;
            color: #7655a3;
            font-size: 26px;
            margin-bottom: 8px;
        }

        .descricao {
            color: #776985;
            line-height: 1.7;
            margin-bottom: 25px;
        }

        /* Resumo */

        .resumo {
            display: flex;
            align-items: center;
            gap: 12px;
            background: #f3edfa;
            padding: 17px 20px;
            border-radius: 13px;
            margin-bottom: 25px;
            color: #594176;
        }

        .resumo strong {
            color: #7655a3;
            font-size: 20px;
        }

        .resumo-icone {
            font-size: 23px;
        }

        /* Tabela */

        .tabela-container {
            overflow-x: auto;
            border-radius: 13px;
            border: 1px solid #eee6f5;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 950px;
        }

        th,
        td {
            padding: 16px 14px;
            text-align: left;
            border-bottom: 1px solid #eee6f5;
            font-size: 14px;
        }

        th {
            background: #7655a3;
            color: white;
            font-weight: 800;
            white-space: nowrap;
        }

        tbody tr {
            transition: 0.2s;
        }

        tbody tr:hover {
            background: #faf7fd;
        }

        tbody tr:last-child td {
            border-bottom: none;
        }

        td {
            color: #594d65;
        }

        .id {
            color: #8e6bbe;
            font-weight: 800;
        }

        .nome-animal {
            color: #594176;
            font-weight: 800;
        }

        .vazio {
            text-align: center;
            padding: 35px;
            color: #91859d;
            font-size: 15px;
        }

        /* Erro */

        .erro {
            color: #b42318;
            background: #fff0ee;
            padding: 16px;
            border-radius: 12px;
            line-height: 1.6;
        }

        /* Rodapé */

        footer {
            text-align: center;
            padding: 25px 10px 5px;
            color: #91859d;
            font-size: 13px;
        }

        /* Responsividade */

        @media (max-width: 600px) {
            body {
                padding: 18px 4%;
            }

            header {
                padding: 18px;
            }

            .logo {
                font-size: 22px;
            }

            .conteudo {
                padding: 21px 16px;
            }

            .titulo {
                font-size: 23px;
            }

            .resumo {
                flex-wrap: wrap;
            }
        }
    </style>
</head>

<body>

    <header>
        <h1 class="logo">Pet <span>Health</span></h1>

        <a class="voltar" href="admin.php">
            Voltar ao painel
        </a>
    </header>

    <main>

        <section class="conteudo">

            <h2 class="titulo">Animais cadastrados</h2>

            <p class="descricao">
                Confira as informações dos animais cadastrados
                e seus respectivos tutores.
            </p>

            <?php if ($erro): ?>

                <p class="erro">
                    Não foi possível carregar os animais.
                    Tente novamente mais tarde.
                </p>

            <?php else: ?>

                <div class="resumo">
                    <span class="resumo-icone">🐾</span>

                    <span>
                        Total de animais encontrados:
                        <strong><?= count($animais) ?></strong>
                    </span>
                </div>

                <div class="tabela-container">

                    <table>

                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nome</th>
                                <th>Tutor</th>
                                <th>Espécie</th>
                                <th>Raça</th>
                                <th>Cor</th>
                                <th>Sexo</th>
                                <th>Data de nascimento</th>
                            </tr>
                        </thead>

                        <tbody>

                            <?php if (count($animais) > 0): ?>

                                <?php foreach ($animais as $animal): ?>

                                    <tr>

                                        <td class="id">
                                            <?= limparTexto($animal['id_animal']) ?>
                                        </td>

                                        <td class="nome-animal">
                                            <?= limparTexto($animal['nome_animal']) ?>
                                        </td>

                                        <td>
                                            <?= limparTexto(
                                                $animal['nome_usuario']
                                                ?? 'Tutor não identificado'
                                            ) ?>
                                        </td>

                                        <td>
                                            <?= limparTexto(
                                                $animal['especie_animal']
                                                ?? 'Não informada'
                                            ) ?>
                                        </td>

                                        <td>
                                            <?= limparTexto($animal['raca_animal']) ?>
                                        </td>

                                        <td>
                                            <?= limparTexto($animal['cor_animal']) ?>
                                        </td>

                                        <td>
                                            <?= limparTexto($animal['sexo_animal']) ?>
                                        </td>

                                        <td>
                                            <?php
                                            if (!empty($animal['data_nascimento_animal'])) {
                                                $data = DateTime::createFromFormat(
                                                    'Y-m-d',
                                                    $animal['data_nascimento_animal']
                                                );

                                                echo $data
                                                    ? $data->format('d/m/Y')
                                                    : limparTexto($animal['data_nascimento_animal']);
                                            } else {
                                                echo 'Não informada';
                                            }
                                            ?>
                                        </td>

                                    </tr>

                                <?php endforeach; ?>

                            <?php else: ?>

                                <tr>
                                    <td colspan="8" class="vazio">
                                        Nenhum animal cadastrado ainda. 🐾
                                    </td>
                                </tr>

                            <?php endif; ?>

                        </tbody>

                    </table>

                </div>

            <?php endif; ?>

        </section>

    </main>

    <footer>
        © 2026 Pet Health — Cuidando de quem faz parte da sua família.
    </footer>

</body>
</html>
