
<?php
session_start();

// Proteção: apenas CLIENTE logado
if (
    !isset($_SESSION['id_usuario']) ||
    ($_SESSION['status'] ?? '') !== 'CLIENTE'
) {
    header('Location: home.php');
    exit;
}

require 'conexao.php';

$id_usuario = (int) $_SESSION['id_usuario'];
$mensagem = '';
$tipoMensagem = '';

// Cancelamento de consulta
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cancelar_id'])) {

    $idCancelar = (int) $_POST['cancelar_id'];

    $stmtCheck = $pdo->prepare("
        SELECT id_consulta, STATUS
        FROM CONSULTAS
        WHERE id_consulta = ? AND id_usuario_fk = ?
    ");
    $stmtCheck->execute([$idCancelar, $id_usuario]);
    $consulta = $stmtCheck->fetch(PDO::FETCH_ASSOC);

    if (!$consulta) {
        $mensagem = 'Consulta não encontrada ou não pertence à sua conta.';
        $tipoMensagem = 'erro';

    } elseif (!in_array($consulta['STATUS'], ['AGENDADA', 'CONFIRMADA'], true)) {
        $mensagem = 'Esta consulta não pode mais ser cancelada.';
        $tipoMensagem = 'erro';

    } else {
        try {
            $stmtUp = $pdo->prepare("
                UPDATE CONSULTAS
                SET STATUS = 'CANCELADA'
                WHERE id_consulta = ? AND id_usuario_fk = ?
            ");
            $stmtUp->execute([$idCancelar, $id_usuario]);

            $mensagem = 'Consulta cancelada com sucesso.';
            $tipoMensagem = 'sucesso';

        } catch (PDOException $e) {
            error_log($e->getMessage());
            $mensagem = 'Erro ao cancelar. Tente novamente.';
            $tipoMensagem = 'erro';
        }
    }
}

// Busca as consultas do cliente
try {
    $stmt = $pdo->prepare("
        SELECT
            c.id_consulta,
            c.data_consulta,
            c.descricao_sintomas,
            c.valor_total,
            c.STATUS,
            a.nome_animal,
            e.nome_especialidade
        FROM CONSULTAS c
        INNER JOIN ANIMAIS a
            ON a.id_animal = c.id_animal_fk
        LEFT JOIN ESPECIALIDADES e
            ON e.id_especialidade = c.id_especialidade_fk
        WHERE c.id_usuario_fk = ?
        ORDER BY
            CASE WHEN c.data_consulta IS NULL THEN 0 ELSE 1 END,
            c.data_consulta DESC,
            c.id_consulta DESC
    ");
    $stmt->execute([$id_usuario]);
    $consultas = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    error_log($e->getMessage());
    $erro = true;
    $mensagem = 'Erro ao carregar consultas.';
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Minhas Consultas | Pet Health</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link href="https://fonts.googleapis.com/css2?family=Coiny&family=Nunito:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Nunito', sans-serif;
        }

        body {
            min-height: 100vh;
            background: linear-gradient(135deg, #f7f1ff, #e9dcfa, #fff4ed);
            color: #665b70;
        }

        header {
            background: #ffffff;
            padding: 18px 8%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 15px;
            flex-wrap: wrap;
            box-shadow: 0 4px 20px rgba(118, 85, 163, 0.08);
        }

        .texto-logo {
            font-family: 'Coiny', system-ui;
            font-size: 30px;
            color: #7655a3;
        }

        .texto-logo span {
            font-family: 'Coiny', system-ui;
            color: #ef713f;
        }

        .sair {
            background: #ef713f;
            color: white;
            padding: 11px 22px;
            text-decoration: none;
            border-radius: 11px;
            font-weight: 800;
            font-size: 14px;
            transition: 0.2s;
            box-shadow: 0 4px 10px rgba(239, 113, 63, 0.2);
        }

        .sair:hover {
            background: #dc6031;
            transform: translateY(-2px);
        }

        main {
            width: 90%;
            max-width: 1100px;
            margin: 40px auto;
        }

        .topo-pagina {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 28px;
            flex-wrap: wrap;
            gap: 15px;
        }

        .topo-pagina h2 {
            font-family: 'Coiny', system-ui;
            font-size: 32px;
            color: #594176;
            font-weight: normal;
        }

        .btn-add {
            background: #ef713f;
            color: white;
            padding: 12px 20px;
            text-decoration: none;
            border-radius: 11px;
            font-weight: 800;
            font-size: 14px;
            transition: 0.2s;
            box-shadow: 0 4px 10px rgba(239, 113, 63, 0.2);
        }

        .btn-add:hover {
            background: #dc6031;
            transform: translateY(-2px);
        }

        .mensagem {
            padding: 14px 18px;
            border-radius: 12px;
            margin-bottom: 22px;
            font-weight: 800;
            text-align: center;
        }

        .mensagem.sucesso {
            background: #e6f7eb;
            color: #2c6e3a;
            border: 1px solid #b7e3c2;
        }

        .mensagem.erro {
            background: #fde8e8;
            color: #a03535;
            border: 1px solid #f5b5b5;
        }

        .grid-consultas {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 22px;
        }

        .card-consulta {
            background: #ffffff;
            border-radius: 20px;
            padding: 25px;
            box-shadow: 0 8px 25px rgba(118, 85, 163, 0.08);
            border-top: 5px solid #ef713f;
            transition: 0.3s ease;
            display: flex;
            flex-direction: column;
        }

        .card-consulta:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 30px rgba(118, 85, 163, 0.15);
        }

        .card-consulta h3 {
            font-family: 'Coiny', system-ui;
            font-size: 23px;
            color: #594176;
            margin-bottom: 4px;
            font-weight: normal;
        }

        .especialidade {
            color: #91859d;
            font-size: 13px;
            font-weight: 700;
            margin-bottom: 15px;
        }

        .info-linha {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 12px;
            padding: 10px 0;
            border-bottom: 1px solid #f0eaf5;
            font-size: 14px;
            color: #776985;
        }

        .info-linha:last-of-type {
            border-bottom: none;
        }

        .info-linha strong {
            color: #594176;
            text-align: right;
            max-width: 65%;
            overflow-wrap: anywhere;
        }

        .badge-status {
            display: inline-block;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 900;
            letter-spacing: 0.3px;
            white-space: nowrap;
        }

        .status-AGENDADA {
            background: #e8f0fe;
            color: #1a56b0;
        }

        .status-CONFIRMADA {
            background: #e6f7eb;
            color: #2c6e3a;
        }

        .status-CANCELADA {
            background: #fde8e8;
            color: #a03535;
        }

        .status-ATENDIDO {
            background: #f0eaf5;
            color: #594176;
        }

        .acoes-card {
            display: flex;
            gap: 10px;
            margin-top: 18px;
            padding-top: 15px;
            border-top: 1px dashed #e5dced;
        }

        .acoes-card form {
            flex: 1;
            margin: 0;
        }

        .btn-acao {
            width: 100%;
            padding: 11px;
            border: none;
            border-radius: 10px;
            font-size: 14px;
            font-weight: 800;
            cursor: pointer;
            transition: 0.2s;
            text-align: center;
            text-decoration: none;
            display: inline-block;
        }

        .btn-cancelar {
            background: #fde8e8;
            color: #a03535;
        }

        .btn-cancelar:hover {
            background: #f8d4d4;
        }

        .msg-vazia {
            background: #ffffff;
            padding: 40px;
            border-radius: 20px;
            text-align: center;
            box-shadow: 0 8px 25px rgba(118, 85, 163, 0.08);
            color: #776985;
        }

        .msg-vazia h3 {
            font-family: 'Coiny', system-ui;
            color: #594176;
            margin-bottom: 10px;
            font-weight: normal;
            font-size: 23px;
        }

        .btn-voltar {
            display: inline-block;
            margin-top: 25px;
            padding: 12px 20px;
            background: #ffffff;
            color: #7655a3;
            text-decoration: none;
            border-radius: 11px;
            font-weight: 800;
            transition: 0.2s;
            box-shadow: 0 4px 12px rgba(118, 85, 163, 0.08);
        }

        .btn-voltar:hover {
            background: #f0eaf8;
            transform: translateY(-2px);
        }

        footer {
            text-align: center;
            padding: 25px 15px;
            color: #91859d;
            font-size: 13px;
        }

        @media (max-width: 768px) {
            header {
                flex-direction: column;
                text-align: center;
                padding: 20px;
            }

            .topo-pagina {
                flex-direction: column;
                text-align: center;
            }

            .topo-pagina h2 {
                font-size: 28px;
            }
        }

        @media (max-width: 400px) {
            .info-linha {
                font-size: 13px;
            }

            .card-consulta {
                padding: 20px;
            }
        }
    </style>
</head>

<body>

    <header>
        <div class="texto-logo">Pet <span>Health</span></div>

        <a class="sair" href="logout.php"
           onclick="return confirm('Tem certeza de que deseja sair da sua conta?');">
            Sair da conta
        </a>
    </header>

    <main>

        <div class="topo-pagina">
            <h2>Minhas Consultas</h2>

            <a href="cadastro.php" class="btn-add">
                + Solicitar nova consulta
            </a>
        </div>

        <?php if ($mensagem !== ''): ?>
            <div class="mensagem <?= htmlspecialchars($tipoMensagem) ?>">
                <?= htmlspecialchars($mensagem) ?>
            </div>
        <?php endif; ?>

        <?php if (isset($erro)): ?>

            <div class="msg-vazia">
                <h3 style="color: #a03535;">Erro ao carregar</h3>
                <p>Tente novamente mais tarde.</p>
            </div>

        <?php elseif (count($consultas) > 0): ?>

            <div class="grid-consultas">

                <?php foreach ($consultas as $c): ?>

                    <?php
                    $status = $c['STATUS'] ?? 'AGENDADA';
                    $podeCancelar = in_array($status, ['AGENDADA', 'CONFIRMADA'], true);

                    // Formatação da data
                    $dataFormatada = 'Aguardando definição da clínica';

                    if (!empty($c['data_consulta'])) {
                        $dt = DateTime::createFromFormat('Y-m-d H:i:s', $c['data_consulta']);

                        if (!$dt) {
                            $dt = DateTime::createFromFormat('Y-m-d H:i', $c['data_consulta']);
                        }

                        if ($dt) {
                            $dataFormatada = $dt->format('d/m/Y \à\s H:i');
                        }
                    }

                    // Formatação do valor
                    $valorFormatado = $c['valor_total'] !== null
                        ? 'R$ ' . number_format((float) $c['valor_total'], 2, ',', '.')
                        : 'A definir';

                    $especialidade = $c['nome_especialidade'] ?? 'A definir';
                    ?>

                    <div class="card-consulta">

                        <h3><?= htmlspecialchars($c['nome_animal']) ?></h3>

                        <p class="especialidade">
                            <?= htmlspecialchars($especialidade) ?>
                        </p>

                        <div class="info-linha">
                            <span>Data:</span>
                            <strong><?= htmlspecialchars($dataFormatada) ?></strong>
                        </div>

                        <div class="info-linha">
                            <span>Valor:</span>
                            <strong><?= htmlspecialchars($valorFormatado) ?></strong>
                        </div>

                        <div class="info-linha">
                            <span>Status:</span>

                            <span class="badge-status status-<?= htmlspecialchars($status) ?>">
                                <?= htmlspecialchars($status) ?>
                            </span>
                        </div>

                        <div class="info-linha">
                            <span>Sintomas:</span>
                            <strong><?= htmlspecialchars($c['descricao_sintomas']) ?></strong>
                        </div>

                        <?php if ($podeCancelar): ?>

                            <div class="acoes-card">

                                <form method="POST"
                                      onsubmit="return confirm('Tem certeza que deseja cancelar esta consulta?');">

                                    <input type="hidden"
                                           name="cancelar_id"
                                           value="<?= (int) $c['id_consulta'] ?>">

                                    <button type="submit" class="btn-acao btn-cancelar">
                                        Cancelar consulta
                                    </button>

                                </form>

                            </div>

                        <?php endif; ?>

                    </div>

                <?php endforeach; ?>

            </div>

        <?php else: ?>

            <div class="msg-vazia">
                <h3>Nenhuma consulta solicitada</h3>

                <p>
                    Você ainda não solicitou nenhuma consulta.
                    Clique no botão acima para pedir a primeira!
                </p>
            </div>

        <?php endif; ?>

        <div style="text-align: center;">
            <a href="cliente.php" class="btn-voltar">
                ← Voltar para a área do cliente
            </a>
        </div>

    </main>

    <footer>
        © 2026 Pet Health — Cuidando de quem faz parte da sua família.
    </footer>

</body>
</html>
