<?php

session_start();

/* 1. Protege a página: somente administradores podem acessá-la. */
if (
    !isset($_SESSION['id_usuario']) ||
    !isset($_SESSION['status']) ||
    $_SESSION['status'] !== 'ADMINISTRADOR'
) {
    header('Location: home.php');
    exit;
}

/* 2. Importa a conexão com o banco de dados. */
require_once 'conexao.php';

/* 3. Busca os veterinários cadastrados. */
try {
    $sql = "SELECT
                v.id_veterinario,
                v.nome_veterinario,
                v.email_usuario,
                v.telefone_usuario,
                v.crm_veterinario,
                v.crm_uf_veterinario,
                e.nome_especialidade
            FROM VETERINARIOS v
            LEFT JOIN ESPECIALIDADES e
                ON v.id_especialidade_fk = e.id_especialidade
            ORDER BY v.nome_veterinario ASC";

    $stmt = $pdo->query($sql);
    $veterinarios = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    error_log($e->getMessage());
    $erro = true;
}

/* 4. Prepara uma função para exibir textos com segurança. */
function limparTexto($texto)
{
    return htmlspecialchars(
        (string) ($texto ?? ''),
        ENT_QUOTES,
        'UTF-8'
    );
}

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Veterinários | Pet Health</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Coiny&family=Nunito:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Nunito', sans-serif;
        }

        body {
            min-height: 100vh;
            background: linear-gradient(
                135deg,
                #f7f1ff,
                #e9dcfa,
                #fff4ed
            );
            color: #594176;
            padding: 30px 5%;
        }

        /* Cabeçalho */

        header {
            background: rgba(255, 255, 255, 0.95);
            padding: 22px 30px;
            border-radius: 18px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
            margin-bottom: 30px;
            box-shadow: 0 4px 18px rgba(89, 65, 118, 0.08);
        }

        header h1 {
            font-family: 'Coiny', cursive;
            color: #7655a3;
            font-size: 26px;
            font-weight: normal;
        }

        .voltar,
        .novo-cadastro {
            display: inline-block;
            padding: 12px 19px;
            text-decoration: none;
            border-radius: 11px;
            font-weight: 800;
            transition: 0.3s;
        }

        .voltar {
            background: #ef713f;
            color: white;
        }

        .voltar:hover,
        .novo-cadastro:hover {
            background: #dc6031;
            transform: translateY(-2px);
        }

        .novo-cadastro {
            background: #ef713f;
            color: white;
            margin-bottom: 22px;
        }

        /* Conteúdo */

        .conteudo {
            background: rgba(255, 255, 255, 0.96);
            padding: 30px;
            border-radius: 20px;
            box-shadow: 0 8px 25px rgba(73, 61, 82, 0.09);
        }

        h2 {
            font-family: 'Coiny', cursive;
            color: #594176;
            font-size: 24px;
            font-weight: normal;
            margin-bottom: 12px;
        }

        .descricao {
            color: #665b70;
            margin-bottom: 22px;
            line-height: 1.7;
            font-size: 15px;
        }

        .resumo {
            background: #f3edfa;
            color: #594176;
            padding: 16px 18px;
            border-radius: 12px;
            margin-bottom: 22px;
            font-size: 15px;
        }

        .resumo strong {
            color: #7655a3;
            font-size: 17px;
        }

        /* Tabela */

        .tabela-container {
            overflow-x: auto;
            border-radius: 12px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 850px;
        }

        th,
        td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #e8e0ef;
            font-size: 14px;
        }

        th {
            background: #f3edfa;
            color: #594176;
            font-weight: 800;
            white-space: nowrap;
        }

        td {
            color: #665b70;
        }

        tbody tr:hover {
            background: #faf7fd;
        }

        tbody tr:last-child td {
            border-bottom: none;
        }

        td a {
            display: inline-block;
            background: #fce9df;
            color: #c6532c;
            padding: 8px 12px;
            border-radius: 9px;
            text-decoration: none;
            font-weight: 800;
            font-size: 13px;
            white-space: nowrap;
            transition: 0.3s;
        }

        td a:hover {
            background: #ef713f;
            color: white;
        }

        .vazio {
            text-align: center;
            padding: 28px;
            color: #665b70;
        }

        /* Mensagem de erro */

        .erro {
            color: #a83232;
            background: #fff0f0;
            padding: 16px;
            border-radius: 10px;
            font-size: 14px;
        }

        /* Responsividade */

        @media (max-width: 600px) {
            body {
                padding: 15px;
            }

            header {
                padding: 20px;
            }

            header h1 {
                font-size: 22px;
            }

            .conteudo {
                padding: 20px;
            }

            h2 {
                font-size: 21px;
            }

            .voltar,
            .novo-cadastro {
                text-align: center;
            }
        }
    </style>
</head>

<body>

    <header>
        <h1>Pet Health | Veterinários</h1>

        <a class="voltar" href="admin.php">
            Voltar ao painel
        </a>
    </header>

    <main class="conteudo">

        <h2>Veterinários cadastrados</h2>

        <p class="descricao">
            Confira os profissionais registrados no sistema,
            suas informações de contato e especialidades.
        </p>

        <a class="novo-cadastro" href="cadastro_veterinario.php">
            + Cadastrar veterinário
        </a>

        <?php if (isset($erro)): ?>

            <p class="erro">
                Não foi possível carregar os veterinários.
                Tente novamente mais tarde.
            </p>

        <?php else: ?>

            <p class="resumo">
                Total de veterinários cadastrados:
                <strong><?= count($veterinarios) ?></strong>
            </p>

            <div class="tabela-container">

                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nome</th>
                            <th>E-mail</th>
                            <th>Telefone</th>
                            <th>CRMV</th>
                            <th>Especialidade</th>
                            <th>Disponibilidade</th>
                        </tr>
                    </thead>

                    <tbody>

                        <?php if (count($veterinarios) > 0): ?>

                            <?php foreach ($veterinarios as $veterinario): ?>

                                <tr>
                                    <td>
                                        <?= limparTexto($veterinario['id_veterinario']) ?>
                                    </td>

                                    <td>
                                        <?= limparTexto($veterinario['nome_veterinario']) ?>
                                    </td>

                                    <td>
                                        <?= limparTexto($veterinario['email_usuario']) ?>
                                    </td>

                                    <td>
                                        <?= limparTexto($veterinario['telefone_usuario']) ?>
                                    </td>

                                    <td>
                                        <?= limparTexto(
                                            'CRMV-' .
                                            $veterinario['crm_uf_veterinario'] .
                                            ' nº ' .
                                            $veterinario['crm_veterinario']
                                        ) ?>
                                    </td>

                                    <td>
                                        <?= limparTexto(
                                            $veterinario['nome_especialidade']
                                            ?? 'Não informada'
                                        ) ?>
                                    </td>

                                    <td>
                                        <a href="disponibilidade_veterinario.php?id=<?= (int) $veterinario['id_veterinario'] ?>">
                                            Configurar agenda
                                        </a>
                                    </td>
                                </tr>

                            <?php endforeach; ?>

                        <?php else: ?>

                            <tr>
                                <td colspan="7" class="vazio">
                                    Nenhum veterinário cadastrado ainda.
                                </td>
                            </tr>

                        <?php endif; ?>

                    </tbody>
                </table>

            </div>

        <?php endif; ?>

    </main>

</body>

</html>
