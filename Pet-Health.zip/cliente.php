<?php

session_start();

// Proteção da página: somente clientes logados.
if (
    !isset($_SESSION['id_usuario']) ||
    !isset($_SESSION['status']) ||
    $_SESSION['status'] !== 'CLIENTE'
) {
    header('Location: home.php');
    exit;
}

$nome = htmlspecialchars(
    $_SESSION['nome_usuario'] ?? 'Cliente',
    ENT_QUOTES,
    'UTF-8'
);

?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Área do Cliente | Pet Health</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link href="https://fonts.googleapis.com/css2?family=Coiny&family=Nunito:wght@400;500;600;700;800&display=swap"
        rel="stylesheet">

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Nunito', sans-serif;
        }

        body {
            min-height: 100vh;
            background: linear-gradient(135deg, #f7f1ff, #e9dcfa, #fff4ed);
            color: #413055;
        }

        /* Cabeçalho */

        header {
            background: #ffffff;
            padding: 16px 8%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 20px;
            flex-wrap: wrap;
            box-shadow: 0 4px 20px rgba(118, 85, 163, 0.08);
        }

        .logo-container {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .logo-container img {
            height: 65px;
            width: auto;
            object-fit: contain;
        }

        .texto-logo {
            font-family: 'Coiny', cursive;
            font-size: 32px;
            color: #7655a3;
        }

        .texto-logo span {
            font-family: 'Coiny', cursive;
            color: #ef713f;
        }

        .sair {
            background: #ef713f;
            color: white;
            padding: 12px 22px;
            text-decoration: none;
            border-radius: 11px;
            font-weight: 800;
            font-size: 14px;
            transition: 0.2s ease;
            box-shadow: 0 4px 10px rgba(239, 113, 63, 0.25);
        }

        .sair:hover {
            background: #dc6031;
            transform: translateY(-2px);
            box-shadow: 0 6px 15px rgba(239, 113, 63, 0.35);
        }

        /* Conteúdo principal */

        main {
            width: 90%;
            max-width: 1100px;
            margin: 42px auto;
        }

        /* Boas-vindas */

        .boas-vindas {
            background: white;
            padding: 40px;
            border-radius: 24px;
            margin-bottom: 32px;
            box-shadow: 0 12px 35px rgba(118, 85, 163, 0.09);
            border: 1px solid rgba(255, 255, 255, 0.8);
            display: flex;
            flex-direction: column;
            gap: 10px;
            position: relative;
            overflow: hidden;
        }

        .boas-vindas::before {
            content: '';
            position: absolute;
            left: 0;
            top: 0;
            bottom: 0;
            width: 6px;
            background: #ef713f;
        }

        .boas-vindas h2 {
            font-family: 'Coiny', cursive;
            font-size: 32px;
            color: #594176;
            font-weight: normal;
        }

        .boas-vindas h2 span {
            font-family: 'Coiny', cursive;
            color: #ef713f;
        }

        .boas-vindas p {
            font-size: 15px;
            line-height: 1.7;
            color: #776985;
            max-width: 800px;
        }

        /* Cards */

        .cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 24px;
        }

        .card {
            background: white;
            padding: 30px;
            border-radius: 20px;
            box-shadow: 0 8px 25px rgba(118, 85, 163, 0.08);
            transition: 0.25s ease;
            border-top: 5px solid #ef713f;
            display: flex;
            flex-direction: column;
            gap: 13px;
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 13px 30px rgba(118, 85, 163, 0.15);
        }

        /* Ícones */

        .card-icon {
            width: 50px;
            height: 50px;
            background: #f7f1ff;
            border-radius: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #7655a3;
            margin-bottom: 3px;
        }

        .card-icon svg {
            width: 25px;
            height: 25px;
            stroke: currentColor;
            stroke-width: 1.8;
            fill: none;
            stroke-linecap: round;
            stroke-linejoin: round;
        }

        .card h2 {
            font-family: 'Coiny', cursive;
            font-size: 23px;
            color: #594176;
            font-weight: normal;
        }

        .card p {
            font-size: 14px;
            line-height: 1.7;
            color: #776985;
            flex: 1;
        }

        /* Botões dos cards */

        .btn-card {
            display: inline-block;
            margin-top: 10px;
            padding: 13px 18px;
            background: #f7f1ff;
            color: #7655a3;
            text-decoration: none;
            border-radius: 11px;
            font-weight: 800;
            font-size: 14px;
            text-align: center;
            transition: 0.2s ease;
        }

        .btn-card:hover {
            background: #e9dcfa;
            color: #594176;
        }

        /* Rodapé */

        footer {
            text-align: center;
            padding: 25px 15px;
            color: #91859d;
            font-size: 13px;
        }

        /* Responsividade */

        @media (max-width: 768px) {

            header {
                flex-direction: column;
                text-align: center;
                padding: 20px;
            }

            .logo-container {
                flex-direction: column;
                gap: 8px;
            }

            .logo-container img {
                height: 60px;
            }

            main {
                margin: 28px auto;
            }

            .boas-vindas {
                padding: 30px 23px;
                text-align: center;
            }

            .boas-vindas h2 {
                font-size: 27px;
            }

            .cards {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 400px) {

            .texto-logo {
                font-size: 28px;
            }

            .boas-vindas h2 {
                font-size: 24px;
            }

            .card {
                padding: 25px;
            }
        }
    </style>
</head>

<body>

    <header>

        <div class="logo-container">

            <img src="imgs/logo.png" alt="Logo Pet Health">

            <div class="texto-logo">
                Pet <span>Health</span>
            </div>

        </div>

        <a class="sair" href="logout.php" onclick="return confirm('Tem certeza de que deseja sair da sua conta?');">
            Sair da conta
        </a>

    </header>

    <main>

        <section class="boas-vindas">

            <h2>Olá, <span><?= $nome ?></span>!</h2>

            <p>
                Bem-vindo(a) à sua área exclusiva. Aqui você pode acompanhar
                a saúde dos seus pets, consultar seu histórico e agendar
                novas consultas com facilidade.
            </p>

        </section>

        <section class="cards">

            <!-- Card Animais -->

            <article class="card">

                <div class="card-icon">

                    <svg viewBox="0 0 24 24">
                        <path
                            d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z" />
                        <circle cx="8.5" cy="10.5" r="1.5" />
                        <circle cx="15.5" cy="10.5" r="1.5" />
                        <circle cx="12" cy="15.5" r="1.5" />
                    </svg>

                </div>

                <h2>Meus Animais</h2>

                <p>
                    Cadastre e gerencie os dados dos seus pets, como raça,
                    idade e informações importantes.
                </p>

                <a href="meus_animais.php" class="btn-card">
                    Gerenciar Animais
                </a>

            </article>

            <!-- Card Agendar Consulta -->

            <article class="card">

                <div class="card-icon">

                    <svg viewBox="0 0 24 24">
                        <rect x="3" y="4" width="18" height="18" rx="2" ry="2" />
                        <line x1="16" y1="2" x2="16" y2="6" />
                        <line x1="8" y1="2" x2="8" y2="6" />
                        <line x1="3" y1="10" x2="21" y2="10" />
                    </svg>

                </div>

                <h2>Agendar Consulta</h2>

                <p>
                    Escolha a especialidade, consulte os horários disponíveis
                    e agende um atendimento para seu pet.
                </p>

                <a href="cadastro.php" class="btn-card">
                    Agendar Agora
                </a>

            </article>

            <!-- Card Histórico -->

            <article class="card">

                <div class="card-icon">

                    <svg viewBox="0 0 24 24">
                        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
                        <polyline points="14 2 14 8 20 8" />
                        <line x1="16" y1="13" x2="8" y2="13" />
                        <line x1="16" y1="17" x2="8" y2="17" />
                        <polyline points="10 9 9 9 8 9" />
                    </svg>

                </div>

                <h2>Minhas Consultas</h2>

                <p>
                    Acompanhe o status dos seus agendamentos e consulte
                    seus atendimentos anteriores e futuros.
                </p>

                <a href="minhas_consultas.php" class="btn-card">
                    Ver Histórico
                </a>

            </article>

        </section>

    </main>

    <footer>
        © 2026 Pet Health — Cuidando de quem faz parte da sua família.
    </footer>

</body>

</html>