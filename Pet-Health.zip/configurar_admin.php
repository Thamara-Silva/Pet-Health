
<?php

require_once 'conexao.php';

$emailAdmin = 'admin@gmail.com';

try {
    $sql = "UPDATE USUARIOS
            SET STATUS = 'ADMINISTRADOR'
            WHERE email_usuario = :email";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':email' => $emailAdmin
    ]);

    if ($stmt->rowCount() > 0) {
        echo "Administrador configurado com sucesso!";
    } else {
        echo "Nenhuma alteração realizada. Verifique se a conta existe.";
    }

} catch (PDOException $e) {
    die("Erro: " . $e->getMessage());
}
