
<?php

session_start();

// Somente administradores podem acessar.
if (
    !isset($_SESSION['id_usuario']) ||
    ($_SESSION['status'] ?? '') !== 'ADMINISTRADOR'
) {
    header('Location: home.php');
    exit;
}

require_once 'conexao.php';

function limparTexto($texto)
{
    return htmlspecialchars(
        (string) ($texto ?? ''),
        ENT_QUOTES,
        'UTF-8'
    );
}

// Recebe o ID do veterinário pela URL.
$idVeterinario = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$idVeterinario || $idVeterinario <= 0) {
    header('Location: veterinarios.php');
    exit;
}

// Busca o veterinário.
$stmt = $pdo->prepare("
    SELECT id_veterinario, nome_veterinario
    FROM VETERINARIOS
    WHERE id_veterinario = ?
");

$stmt->execute([$idVeterinario]);
$veterinario = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$veterinario) {
    header('Location: veterinarios.php');
    exit;
}

$diasSemana = [
    1 => 'Segunda-feira',
    2 => 'Terça-feira',
    3 => 'Quarta-feira',
    4 => 'Quinta-feira',
    5 => 'Sexta-feira',
    6 => 'Sábado',
    7 => 'Domingo'
];

$mensagem = '';
$tipoMensagem = '';

// Processa os formulários.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $acao = $_POST['acao'] ?? '';

    try {

        // Cadastra uma disponibilidade.
        if ($acao === 'cadastrar') {

            $diaSemana = filter_input(
                INPUT_POST,
                'dia_semana',
                FILTER_VALIDATE_INT
            );

            $horaInicio = $_POST['hora_inicio'] ?? '';
            $horaFim = $_POST['hora_fim'] ?? '';

            if (
                !$diaSemana ||
                $diaSemana < 1 ||
                $diaSemana > 7
            ) {
                throw new Exception('Selecione um dia válido.');
            }

            if (
                !preg_match('/^\d{2}:\d{2}$/', $horaInicio) ||
                !preg_match('/^\d{2}:\d{2}$/', $horaFim)
            ) {
                throw new Exception('Informe horários válidos.');
            }

            if ($horaInicio >= $horaFim) {
                throw new Exception(
                    'O horário final deve ser posterior ao inicial.'
                );
            }

            // Verifica se existe algum período sobreposto.
            $stmt = $pdo->prepare("
                SELECT COUNT(*)
                FROM DISPONIBILIDADE_VETERINARIOS
                WHERE id_veterinario_fk = ?
                  AND dia_semana = ?
                  AND ativo = TRUE
                  AND hora_inicio < ?
                  AND hora_fim > ?
            ");

            $stmt->execute([
                $idVeterinario,
                $diaSemana,
                $horaFim,
                $horaInicio
            ]);

            if ($stmt->fetchColumn() > 0) {
                throw new Exception(
                    'Esse período se sobrepõe a uma disponibilidade já cadastrada.'
                );
            }

            // Salva a disponibilidade.
            $stmt = $pdo->prepare("
                INSERT INTO DISPONIBILIDADE_VETERINARIOS
                (
                    id_veterinario_fk,
                    dia_semana,
                    hora_inicio,
                    hora_fim
                )
                VALUES (?, ?, ?, ?)
            ");

            $stmt->execute([
                $idVeterinario,
                $diaSemana,
                $horaInicio,
                $horaFim
            ]);

            $mensagem = 'Disponibilidade cadastrada com sucesso!';
            $tipoMensagem = 'sucesso';
        }

        // Exclui uma disponibilidade.
        elseif ($acao === 'excluir') {

            $idDisponibilidade = filter_input(
                INPUT_POST,
                'id_disponibilidade',
                FILTER_VALIDATE_INT
            );

            if (!$idDisponibilidade || $idDisponibilidade <= 0) {
                throw new Exception('Disponibilidade inválida.');
            }

            $stmt = $pdo->prepare("
                DELETE FROM DISPONIBILIDADE_VETERINARIOS
                WHERE id_disponibilidade = ?
                  AND id_veterinario_fk = ?
            ");

            $stmt->execute([
                $idDisponibilidade,
                $idVeterinario
            ]);

            if ($stmt->rowCount() > 0) {
                $mensagem = 'Disponibilidade excluída com sucesso!';
                $tipoMensagem = 'sucesso';
            } else {
                throw new Exception('Não foi possível excluir o horário.');
            }
        }

    } catch (Exception $e) {
        $mensagem = $e->getMessage();
        $tipoMensagem = 'erro';

    } catch (PDOException $e) {
        error_log($e->getMessage());
        $mensagem = 'Ocorreu um erro ao salvar a disponibilidade.';
        $tipoMensagem = 'erro';
    }
}

// Busca as disponibilidades cadastradas.
$stmt = $pdo->prepare("
    SELECT *
    FROM DISPONIBILIDADE_VETERINARIOS
    WHERE id_veterinario_fk = ?
    ORDER BY dia_semana, hora_inicio
");

$stmt->execute([$idVeterinario]);
$disponibilidades = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Disponibilidade | Pet Health</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Coiny&family=Nunito:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Nunito', sans-serif;
        }

        body {
            min-height: 100vh;
            background: linear-gradient(135deg, #f7f1ff, #e9dcfa, #fff4ed);
            color: #594176;
            padding: 30px 5%;
        }

        /* Cabeçalho */

        header {
            background: #ffffff;
            padding: 18px 25px;
            border-radius: 16px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
            margin-bottom: 28px;
            box-shadow: 0 5px 20px rgba(118, 85, 163, 0.08);
        }

        header h1 {
            font-family: 'Coiny', cursive;
            font-size: 25px;
            font-weight: normal;
            color: #7655a3;
        }

        header h1 span {
            font-family: 'Coiny', cursive;
            color: #ef713f;
        }

        .voltar {
            background: #ef713f;
            color: white;
            padding: 11px 19px;
            text-decoration: none;
            border-radius: 10px;
            font-weight: 800;
            font-size: 14px;
            transition: 0.2s;
        }

        .voltar:hover {
            background: #dc6031;
            transform: translateY(-2px);
        }

        /* Conteúdo */

        .conteudo {
            background: #ffffff;
            padding: 30px;
            border-radius: 18px;
            box-shadow: 0 8px 25px rgba(118, 85, 163, 0.08);
            margin-bottom: 24px;
        }

        h2 {
            font-family: 'Coiny', cursive;
            font-size: 24px;
            font-weight: normal;
            color: #7655a3;
            margin-bottom: 9px;
        }

        .descricao {
            line-height: 1.6;
            margin-bottom: 23px;
            color: #776985;
            font-size: 14px;
        }

        /* Formulário */

        .formulario {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 18px;
            align-items: end;
        }

        .campo {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        label {
            font-weight: 800;
            color: #594176;
            font-size: 14px;
        }

        input,
        select {
            width: 100%;
            padding: 12px;
            border: 1px solid #dfd2ee;
            border-radius: 9px;
            outline: none;
            font-size: 14px;
            background: #ffffff;
            color: #594176;
            transition: 0.2s;
        }

        input:focus,
        select:focus {
            border-color: #a88bc9;
            box-shadow: 0 0 0 3px rgba(118, 85, 163, 0.10);
        }

        button {
            border: none;
            cursor: pointer;
            font-weight: 800;
            border-radius: 9px;
            font-size: 14px;
            transition: 0.2s;
        }

        .salvar {
            background: #ef713f;
            color: white;
            padding: 13px;
            grid-column: 1 / -1;
        }

        .salvar:hover {
            background: #dc6031;
            transform: translateY(-1px);
        }

        /* Mensagens */

        .mensagem {
            padding: 14px 16px;
            border-radius: 10px;
            margin-bottom: 20px;
            font-size: 14px;
            font-weight: 700;
        }

        .sucesso {
            background: #e9f8ed;
            color: #246b37;
            border-left: 4px solid #3ba65c;
        }

        .erro {
            background: #fff0ee;
            color: #b42318;
            border-left: 4px solid #d92d20;
        }

        /* Tabela */

        .tabela-container {
            overflow-x: auto;
            border: 1px solid #eee5f7;
            border-radius: 12px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 500px;
        }

        th,
        td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #eee8f5;
            font-size: 14px;
        }

        th {
            background: #f3edfa;
            color: #7655a3;
            font-weight: 800;
        }

        td {
            color: #665b70;
        }

        tbody tr:hover {
            background: #fcf9ff;
        }

        tbody tr:last-child td {
            border-bottom: none;
        }

        .excluir {
            background: #fff0ee;
            color: #b42318;
            padding: 9px 14px;
        }

        .excluir:hover {
            background: #ffe1dc;
        }

        .vazio {
            text-align: center;
            padding: 28px;
            color: #91859d;
        }

        /* Rodapé */

        footer {
            text-align: center;
            padding: 15px 10px 5px;
            color: #91859d;
            font-size: 13px;
        }

        /* Responsividade */

        @media (max-width: 800px) {
            .formulario {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }

            .salvar {
                grid-column: 1 / -1;
            }
        }

        @media (max-width: 600px) {
            body {
                padding: 15px;
            }

            header {
                padding: 18px;
            }

            header h1 {
                font-size: 21px;
            }

            .voltar {
                width: 100%;
                text-align: center;
            }

            .formulario {
                grid-template-columns: 1fr;
            }

            .conteudo {
                padding: 20px 16px;
            }

            h2 {
                font-size: 22px;
            }
        }
    </style>
</head>

<body>

    <header>
        <h1>Pet <span>Health</span> | Disponibilidade</h1>

        <a href="veterinarios.php" class="voltar">
            Voltar aos veterinários
        </a>
    </header>

    <main>

        <section class="conteudo">

            <h2>
                Agenda de <?= limparTexto($veterinario['nome_veterinario']) ?>
            </h2>

            <p class="descricao">
                Configure os dias e horários em que este profissional
                estará disponível para atender. Cada consulta terá
                duração de uma hora.
            </p>

            <?php if ($mensagem): ?>
                <p class="mensagem <?= limparTexto($tipoMensagem) ?>">
                    <?= limparTexto($mensagem) ?>
                </p>
            <?php endif; ?>

            <form method="POST" class="formulario">

                <input type="hidden" name="acao" value="cadastrar">

                <div class="campo">
                    <label for="dia_semana">Dia da semana</label>

                    <select name="dia_semana" id="dia_semana" required>
                        <option value="">Selecione</option>

                        <?php foreach ($diasSemana as $numero => $dia): ?>
                            <option value="<?= $numero ?>">
                                <?= limparTexto($dia) ?>
                            </option>
                        <?php endforeach; ?>

                    </select>
                </div>

                <div class="campo">
                    <label for="hora_inicio">Início do atendimento</label>

                    <input
                        type="time"
                        name="hora_inicio"
                        id="hora_inicio"
                        required
                    >
                </div>

                <div class="campo">
                    <label for="hora_fim">Fim do atendimento</label>

                    <input
                        type="time"
                        name="hora_fim"
                        id="hora_fim"
                        required
                    >
                </div>

                <button type="submit" class="salvar">
                    Cadastrar disponibilidade
                </button>

            </form>

        </section>

        <section class="conteudo">

            <h2>Horários cadastrados</h2>

            <p class="descricao">
                Confira os períodos de atendimento deste veterinário.
            </p>

            <div class="tabela-container">

                <table>

                    <thead>
                        <tr>
                            <th>Dia</th>
                            <th>Início</th>
                            <th>Fim</th>
                            <th>Ação</th>
                        </tr>
                    </thead>

                    <tbody>

                        <?php if (count($disponibilidades) > 0): ?>

                            <?php foreach ($disponibilidades as $item): ?>

                                <tr>
                                    <td>
                                        <?= limparTexto(
                                            $diasSemana[(int) $item['dia_semana']] ?? 'Inválido'
                                        ) ?>
                                    </td>

                                    <td>
                                        <?= limparTexto(substr($item['hora_inicio'], 0, 5)) ?>
                                    </td>

                                    <td>
                                        <?= limparTexto(substr($item['hora_fim'], 0, 5)) ?>
                                    </td>

                                    <td>
                                        <form
                                            method="POST"
                                            onsubmit="return confirm('Deseja excluir esta disponibilidade?');"
                                        >

                                            <input
                                                type="hidden"
                                                name="acao"
                                                value="excluir"
                                            >

                                            <input
                                                type="hidden"
                                                name="id_disponibilidade"
                                                value="<?= (int) $item['id_disponibilidade'] ?>"
                                            >

                                            <button type="submit" class="excluir">
                                                Excluir
                                            </button>

                                        </form>
                                    </td>
                                </tr>

                            <?php endforeach; ?>

                        <?php else: ?>

                            <tr>
                                <td colspan="4" class="vazio">
                                    Nenhuma disponibilidade cadastrada.
                                </td>
                            </tr>

                        <?php endif; ?>

                    </tbody>

                </table>

            </div>

        </section>

    </main>

    <footer>
        © 2026 Pet Health — Cuidando de quem faz parte da sua família.
    </footer>

</body>
</html>
