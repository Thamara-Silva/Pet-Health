
<?php

session_start();

// 1. Verifica se o usuário é administrador.
if (
    !isset($_SESSION['id_usuario']) ||
    ($_SESSION['status'] ?? '') !== 'ADMINISTRADOR'
) {
    header('Location: home.php');
    exit;
}

// 2. Protege o nome antes de exibi-lo.
$nome = htmlspecialchars(
    $_SESSION['nome_usuario'] ?? 'Administrador',
    ENT_QUOTES,
    'UTF-8'
);

// 3. Importa a conexão.
require_once 'conexao.php';

// 4. Busca os totais do sistema.
$erroContadores = false;

try {
    $totalConsultas = (int) $pdo
        ->query("SELECT COUNT(*) FROM CONSULTAS")
        ->fetchColumn();

    $totalAnimais = (int) $pdo
        ->query("SELECT COUNT(*) FROM ANIMAIS")
        ->fetchColumn();

    $totalVeterinarios = (int) $pdo
        ->query("SELECT COUNT(*) FROM VETERINARIOS")
        ->fetchColumn();

} catch (PDOException $e) {
    error_log($e->getMessage());
    $erroContadores = true;
}

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Painel Administrativo | Pet Health</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Coiny&family=Nunito:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Nunito', sans-serif;
        }

        body {
            min-height: 100vh;
            background: linear-gradient(
                135deg,
                #f7f1ff,
                #e9dcfa,
                #fff4ed
            );
            color: #594176;
        }

        /* Cabeçalho */

        header {
            background: rgba(255, 255, 255, 0.94);
            padding: 20px 7%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 20px;
            flex-wrap: wrap;
            box-shadow: 0 4px 18px rgba(89, 65, 118, 0.08);
        }

        .logo {
            font-family: 'Coiny', cursive;
            font-size: 27px;
            color: #7655a3;
        }

        .logo span {
            font-family: 'Coiny', cursive;
            color: #ef713f;
        }

        .sair {
            background: #ef713f;
            color: white;
            padding: 11px 21px;
            text-decoration: none;
            border-radius: 12px;
            font-weight: 800;
            transition: 0.3s;
        }

        .sair:hover {
            background: #dc6031;
            transform: translateY(-2px);
        }

        /* Conteúdo principal */

        main {
            width: 88%;
            max-width: 1200px;
            margin: 45px auto;
        }

        .boas-vindas {
            background: rgba(255, 255, 255, 0.95);
            padding: 35px;
            border-radius: 22px;
            margin-bottom: 30px;
            box-shadow: 0 8px 25px rgba(73, 61, 82, 0.08);
            border-left: 6px solid #ef713f;
        }

        .boas-vindas h2 {
            font-family: 'Coiny', cursive;
            font-size: 27px;
            color: #594176;
            margin-bottom: 10px;
        }

        .boas-vindas p {
            color: #665b70;
            line-height: 1.7;
            font-size: 15px;
        }

        .titulo-secao {
            font-family: 'Coiny', cursive;
            color: #594176;
            font-size: 23px;
            margin-bottom: 20px;
        }

        /* Cards */

        .cards {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 22px;
        }

        .card {
            background: white;
            padding: 28px;
            border-radius: 20px;
            box-shadow: 0 8px 25px rgba(73, 61, 82, 0.09);
            border-top: 5px solid #a58ad0;
            transition: 0.3s;
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 13px 30px rgba(73, 61, 82, 0.14);
        }

        .icone {
            width: 52px;
            height: 52px;
            background: #f1e9fc;
            border-radius: 15px;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 25px;
            margin-bottom: 18px;
        }

        .card h3 {
            color: #594176;
            font-size: 19px;
            font-weight: 800;
            margin-bottom: 8px;
        }

        .numero {
            color: #7655a3;
            font-size: 39px;
            font-weight: 800;
            margin: 12px 0 5px;
        }

        .descricao {
            color: #665b70;
            font-size: 14px;
            line-height: 1.5;
        }

        .botao {
            display: inline-block;
            margin-top: 22px;
            padding: 12px 19px;
            background: #ef713f;
            color: white;
            text-decoration: none;
            border-radius: 11px;
            font-weight: 800;
            font-size: 14px;
            transition: 0.3s;
        }

        .botao:hover {
            background: #dc6031;
            transform: translateY(-2px);
        }

        /* Mensagem de erro */

        .erro {
            color: #a83232;
            background: #fff0f0;
            border-radius: 10px;
            padding: 12px;
            margin-top: 15px;
            font-size: 14px;
        }

        /* Rodapé */

        footer {
            text-align: center;
            padding: 25px 15px;
            color: #665b70;
            font-size: 13px;
        }

        /* Responsividade */

        @media (max-width: 850px) {
            .cards {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }
        }

        @media (max-width: 580px) {
            header {
                padding: 18px 5%;
            }

            .logo {
                font-size: 23px;
            }

            main {
                width: 90%;
                margin: 28px auto;
            }

            .boas-vindas {
                padding: 25px;
            }

            .boas-vindas h2 {
                font-size: 23px;
            }

            .cards {
                grid-template-columns: 1fr;
            }

            .card {
                padding: 24px;
            }
        }
    </style>
</head>

<body>

    <header>
        <h1 class="logo">Pet <span>Health</span></h1>

        <a
            class="sair"
            href="logout.php"
            onclick="return confirm('Tem certeza de que deseja sair da sua conta?');"
        >
            Sair da conta
        </a>
    </header>

    <main>

        <section class="boas-vindas">
            <h2>Olá, <?= $nome ?>!</h2>

            <p>Bem-vindo(a) ao painel administrativo.</p>
            <p>Gerencie as informações e acompanhe o funcionamento da clínica.</p>
        </section>

        <h2 class="titulo-secao">Visão geral da clínica</h2>

        <section class="cards">

            <article class="card">
                <div class="icone">📅</div>

                <h3>Consultas</h3>

                <?php if ($erroContadores): ?>
                    <p class="erro">Não foi possível carregar os dados.</p>
                <?php else: ?>
                    <p class="numero"><?= $totalConsultas ?></p>
                    <p class="descricao">Consultas registradas no sistema.</p>
                <?php endif; ?>

                <a class="botao" href="consultas.php">
                    Ver consultas
                </a>
            </article>

            <article class="card">
                <div class="icone">🐾</div>

                <h3>Animais</h3>

                <?php if ($erroContadores): ?>
                    <p class="erro">Não foi possível carregar os dados.</p>
                <?php else: ?>
                    <p class="numero"><?= $totalAnimais ?></p>
                    <p class="descricao">Animais cadastrados no sistema.</p>
                <?php endif; ?>

                <a class="botao" href="animais.php">
                    Ver animais
                </a>
            </article>

            <article class="card">
                <div class="icone">🩺</div>

                <h3>Veterinários</h3>

                <?php if ($erroContadores): ?>
                    <p class="erro">Não foi possível carregar os dados.</p>
                <?php else: ?>
                    <p class="numero"><?= $totalVeterinarios ?></p>
                    <p class="descricao">Veterinários cadastrados no sistema.</p>
                <?php endif; ?>

                <a class="botao" href="veterinarios.php">
                    Gerenciar veterinários
                </a>
            </article>

        </section>

    </main>

    <footer>
        © 2026 Pet Health — Cuidando de quem faz parte da sua família.
    </footer>

</body>
</html>
